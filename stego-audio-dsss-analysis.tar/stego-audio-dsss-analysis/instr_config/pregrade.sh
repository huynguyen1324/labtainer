#!/bin/bash
# Pre-grading script for stego-audio-dsss-analysis
# This script runs in the grading container before evaluating goals.
# It checks the student's output files and generates the results.txt file.

homedir=$1
destdir=$2

exec > /home/instructor/.local/flask/static/lab_doc/pregrade_run.log 2>&1
echo "=== PREGRADE RUN ==="
echo "homedir: $homedir"
echo "destdir: $destdir"
echo "Current directory before cd:"
pwd

cd $homedir/$destdir
echo "Current directory after cd:"
pwd
echo "Directory contents:"
ls -la

# Ensure output directory exists
mkdir -p .local/result/var/tmp
RESULT_FILE=".local/result/var/tmp/results.txt"
> $RESULT_FILE
echo "Created RESULT_FILE at $RESULT_FILE"

# Task 1: Check PN sequence
if [ -f task1_pn.txt ]; then
    echo "Found task1_pn.txt"
    pn_val=$(cat task1_pn.txt | tr -d '[:space:],')
    echo "pn_val: $pn_val"
    if [ "$pn_val" = "1-1-1-11-111-1-1111-1" ] || [ "$pn_val" = "1-1-1-11-111-1-11111-1" ]; then
        echo "TASK1_OK" >> $RESULT_FILE
        echo "Task 1 OK"
    fi
else
    echo "task1_pn.txt NOT found"
fi

# Task 2: Check audio path
if [ -f task2_path.txt ]; then
    echo "Found task2_path.txt"
    path_val=$(cat task2_path.txt | tr -d '[:space:]')
    echo "path_val: $path_val"
    if [ "$path_val" = "/home/ubuntu/stego_audio.wav" ]; then
        echo "TASK2_OK" >> $RESULT_FILE
        echo "Task 2 OK"
    fi
else
    echo "task2_path.txt NOT found"
fi

# Task 3: Check demodulated binary stream
if [ -f task3_demod.txt ]; then
    echo "Found task3_demod.txt"
    bin_val=$(cat task3_demod.txt | tr -d '[:space:]')
    TARGET_BIN="01000110010011000100000101000111011110110100010001010011010100110101001101011111010100110101010001000101010001110100111101011111010000010101010101000100010010010100111101011111010000010100110001000001010011000101100101010011010010010101001101111101"
    if [[ "$bin_val" == "$TARGET_BIN"* ]] || [[ "$bin_val" =~ ^01000110010011000100000101000111 ]]; then
        echo "TASK3_OK" >> $RESULT_FILE
        echo "Task 3 OK"
    fi
else
    echo "task3_demod.txt NOT found"
fi

# Task 4: Check decoded flag
if [ -f task4_flag.txt ]; then
    echo "Found task4_flag.txt"
    flag_val=$(cat task4_flag.txt | tr -d '[:space:]')
    echo "flag_val: $flag_val"
    if [ "$flag_val" = "FLAG{DSSS_STEGO_AUDIO_ANALYSIS}" ] || [ "$flag_val" = "FLAG{DSSS_STEGO_AUDIO_ALALYSIS}" ] || [[ "$flag_val" =~ ^FLAG\{DSSS_.*\}$ ]]; then
        echo "TASK4_OK" >> $RESULT_FILE
        echo "Task 4 OK"
    fi
else
    echo "task4_flag.txt NOT found"
fi

# Task 5: Check permissions on the home directory
perm_home=$(stat -c "%a" .)
echo "perm_home: $perm_home"
chmod_run=0
if [ -f .bash_history ]; then
    echo "Found .bash_history"
    if grep -q "chmod 700" .bash_history || grep -q "chmod.*700" .bash_history; then
        chmod_run=1
        echo "chmod 700 found in bash history"
    fi
else
    echo ".bash_history NOT found"
fi

if [ "$perm_home" = "700" ] || [ "$perm_home" = "0700" ] || [ $chmod_run -eq 1 ]; then
    echo "TASK5_OK" >> $RESULT_FILE
    echo "Task 5 OK"
fi

echo "Created results.txt contents:"
cat $RESULT_FILE
