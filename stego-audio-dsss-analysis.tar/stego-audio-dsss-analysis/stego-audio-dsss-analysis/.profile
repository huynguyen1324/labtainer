# ~/.profile: executed by the command interpreter for login shells.

# 1. Prevent instructions.txt from auto-launching in 'less' on startup
if [ -f "$HOME/instructions.txt" ]; then
    # Move it to a safe place as 'huong_dan.txt' and delete original so 'less' is bypassed
    mv "$HOME/instructions.txt" "$HOME/huong_dan.txt"
fi

# 2. Standard bash integration
if [ -n "$BASH_VERSION" ]; then
    # include .bashrc if it exists
    if [ -f "$HOME/.bashrc" ]; then
	. "$HOME/.bashrc"
    fi
fi

# 3. Include user's private bin directories
if [ -d "$HOME/bin" ] ; then
    PATH="$HOME/bin:$PATH"
fi

if [ -d "$HOME/.local/bin" ] ; then
    PATH="$HOME/.local/bin:$PATH"
fi
