# demodulate.py
import wave
import struct
import os

home = os.environ.get("HOME", "/home/ubuntu")

# 1. Read PN sequence from task1_pn.txt
with open(os.path.join(home, "task1_pn.txt"), "r") as f:
    pn_str = f.read().strip()
pn = [int(x.strip()) for x in pn_str.split(",")]

# 2. Read stego WAV file
wav_path = os.path.join(home, "stego_audio.wav")
if not os.path.exists(wav_path):
    wav_path = "stego_audio.wav"

with wave.open(wav_path, "r") as f:
    n_frames = f.getnframes()
    data = f.readframes(n_frames)

# convert raw frames to list of floats
samples = []
for i in range(0, len(data), 2):
    val = struct.unpack('<h', data[i:i+2])[0]
    samples.append(val / 32767.0)

# 3. Demodulate using cross-correlation of 15 samples per bit
bits = []
n_bits = len(samples) // 15
for k in range(n_bits):
    block = samples[k*15 : (k+1)*15]
    # compute correlation decision metric
    d_k = sum(block[i] * pn[i] for i in range(15))
    if d_k > 0:
        bits.append("1")
    else:
        bits.append("0")

bitstream = "".join(bits)

# 4. Save results to task3_demod.txt
with open(os.path.join(home, "task3_demod.txt"), "w") as f:
    f.write(bitstream + "\n")

print("Demodulated successfully! Saved bitstream to task3_demod.txt.")
