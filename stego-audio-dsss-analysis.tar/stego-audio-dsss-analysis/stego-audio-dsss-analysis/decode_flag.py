# decode_flag.py
import os

home = os.environ.get("HOME", "/home/ubuntu")

# 1. Read binary bitstream
with open(os.path.join(home, "task3_demod.txt"), "r") as f:
    bitstream = f.read().strip()

# 2. Decode each byte block to ASCII characters
chars = []
for i in range(0, len(bitstream), 8):
    byte_str = bitstream[i:i+8]
    if len(byte_str) == 8:
        val = int(byte_str, 2)
        chars.append(chr(val))

flag = "".join(chars)

# 3. Save flag to task4_flag.txt
with open(os.path.join(home, "task4_flag.txt"), "w") as f:
    f.write(flag + "\n")

print(f"Decoded flag successfully: {flag}")
