# generate_audio.py
import wave
import struct
import math
import os

# 1. Define Message and Convert to Binary Bits
msg = "FLAG{DSSS_STEGO_AUDIO_ANALYSIS}"
bits = []
for char in msg:
    bin_str = format(ord(char), '08b')
    for b in bin_str:
        bits.append(int(b))

# 2. Define 15-bit PN sequence (spreading code)
pn = [1, -1, -1, -1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1]

# 3. Modulate message onto a carrier audio signal using DSSS stego
fs = 8000
alpha = 0.2

samples = []
for k, bit in enumerate(bits):
    d = 1 if bit == 1 else -1
    for i in range(15):
        t = k * 15 + i
        # Carrier: 440 Hz Sine wave
        s = 0.5 * math.sin(2 * math.pi * 440 * t / fs)
        # Bipolar Spread Signal: s + alpha * d * pn[i]
        stego = s + alpha * d * pn[i]
        stego = max(-1.0, min(1.0, stego))
        val = int(stego * 32767)
        samples.append(val)

# 4. Save to wave file
home = os.environ.get("HOME", "/home/ubuntu")
wav_path = os.path.join(home, "stego_audio.wav")

with wave.open(wav_path, "w") as f:
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(fs)
    for s in samples:
        f.writeframesraw(struct.pack('<h', s))

print("Generated stego_audio.wav successfully!")
