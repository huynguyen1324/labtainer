# create_pn.py
import os

pn = [1, -1, -1, -1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1]
pn_str = ", ".join(map(str, pn))

home = os.environ.get("HOME", "/home/ubuntu")
with open(os.path.join(home, "task1_pn.txt"), "w") as f:
    f.write(pn_str + "\n")

print("Created task1_pn.txt successfully!")
