# HƯỚNG DẪN THỰC HÀNH BÀI LAB: DHCP FLOODING (QUA DHCP RELAY)

---

## 1. Sơ đồ mạng và phân bổ IP (Topology)

| Máy (Container) | Mạng kết nối | Địa chỉ IP | Vai trò |
| :--- | :--- | :--- | :--- |
| **`dhcpserver`** | `INTERNAL_NET` (192.168.0.0/24) | `192.168.0.100` (Tĩnh) | Cung cấp IP động (Pool: `10.10.0.100 - 10.10.0.130`) |
| **`dhcprelay`** | Nối cả 2 mạng | eth0: `192.168.0.1`<br>eth1: `10.10.0.1` | Chuyển tiếp DHCP giữa External $\leftrightarrow$ Internal |
| **`client`** | `EXTERNAL_NET` (10.10.0.0/24) | *Chưa có IP* (Dynamic) | Máy nạn nhân xin cấp IP động qua Relay |
| **`attacker`** | `EXTERNAL_NET` (10.10.0.0/24) | *Chưa có IP* (Dynamic) | Máy tấn công tạo bão gói tin DHCP Discover bằng `yersinia` |

---

## 2. GIAI ĐOẠN 1: Khởi động dịch vụ và cấp phát IP bình thường

### Bước 1: Kiểm tra DHCP Server
Trên cửa sổ terminal **`dhcpserver`**:
```bash
# Image khởi động dịch vụ và cấu hình route khi container boot.
systemctl status dhcp-server-init.service --no-pager
pgrep -a dhcpd
ip route show
```
> [!NOTE]
> Nếu `dhcpd` chưa chạy, kiểm tra trạng thái service và cấu hình DHCP trước khi tiếp tục.

> **Điều kiện đạt checkwork:** Không có (Bước chuẩn bị hạ tầng mạng và khởi động dịch vụ máy chủ).

---

### Bước 2: Kiểm tra DHCP Relay
Trên cửa sổ terminal **`dhcprelay`**:
```bash
# Image bật forwarding và khởi động relay khi container boot.
systemctl status dhcp-relay-init.service --no-pager
sysctl net.ipv4.ip_forward
pgrep -a dhcrelay

# Giám sát lưu lượng DHCP
tcpdump -i any -n port 67 or port 68
```

> **Điều kiện đạt checkwork:** Không có (Bước chuẩn bị chuyển tiếp DHCP và kích hoạt giám sát lưu lượng).

---

### Bước 3: Máy Client xin cấp phát IP qua Relay
Trên cửa sổ terminal **`client`**:
```bash
# 1. Kiểm tra ban đầu: Card mạng chưa có địa chỉ IPv4
ip addr show eth0

# 2. Thực hiện xin cấp phát IP động bằng lệnh dhclient
dhclient -v eth0
```
> [!TIP]
> - Máy `client` sẽ hoàn thành bắt tay 4 bước: `DHCPDISCOVER` $\rightarrow$ `DHCPOFFER` $\rightarrow$ `DHCPREQUEST` $\rightarrow$ `DHCPACK` chỉ trong tích tắc (< 0.2s).

Kiểm tra lại thông tin IP và Default Gateway nhận được:
```bash
ip addr show eth0
ip route show
```

> **Điều kiện đạt checkwork:** Mục tiêu **`client_has_ip`** chuyển sang **Y** khi file `/var/lib/dhcp/dhclient.leases` trên máy `client` ghi nhận địa chỉ IP động được cấp phát từ DHCP Server trong dải `10.10.0.0/24`.

---

### Bước 4: Máy Attacker xin cấp phát IP ban đầu
Trước khi tấn công, Attacker cũng cần có IP trong mạng External:
Trên cửa sổ terminal **`attacker`**:
```bash
# Xin cấp phát IP động từ DHCP Server
dhclient -v eth0
```

> **Điều kiện đạt checkwork:** Mục tiêu **`attacker_has_ip`** chuyển sang **Y** khi file `/var/lib/dhcp/dhclient.leases` trên máy `attacker` ghi nhận địa chỉ IP động được cấp phát từ DHCP Server trong dải `10.10.0.0/24`.

---

### Bước 5: Kiểm tra trạng thái cấp phát trên DHCP Server
Trên cửa sổ terminal **`dhcpserver`**:
```bash
# Xem các hợp đồng cấp phát IP (leases) đang hoạt động
cat /var/lib/dhcp/dhcpd.leases
```
*Bạn sẽ thấy hai bản ghi lease cấp phát `10.10.0.100` cho Client và `10.10.0.101` cho Attacker.*

> **Điều kiện đạt checkwork:** Không có (Bước quan sát và kiểm tra các hợp đồng lease được lưu trữ trên Server).

---

## 3. GIAI ĐOẠN 2: Thực hiện tấn công DHCP Flooding bằng `yersinia`

**Mục tiêu:** Attacker phát tán bão gói tin `DHCP Discover` với tốc độ cao nhằm làm nghẽn băng thông và quá tải hàng đợi của Relay / Server.

### Bước 6: Khởi chạy tấn công từ Attacker bằng Yersinia
Trên cửa sổ terminal **`attacker`**:
```bash
yersinia -I
```

**Thao tác trong giao diện ncurses của Yersinia:**
1. Nhấn phím **`g`** (chọn giao thức).
2. Dùng phím mũi tên di chuyển chọn dòng **`DHCP`**, nhấn **`Enter`**.
3. Nhấn phím **`x`** (mở danh sách kiểu tấn công - Attack menu).
4. Chọn mode **`1: sending DISCOVER packet`**, nhấn **`Enter`**.

*(Lúc này, Yersinia phát sinh hàng nghìn gói tin DHCP Discover ra card `eth0` với tốc độ cực nhanh).*

> **Điều kiện đạt checkwork:** Mục tiêu **`flooding_attack`** chuyển sang **Y** khi lệnh/tiến trình `yersinia` được kích hoạt và ghi nhận trên máy `attacker`.

---

### Bước 7: Quan sát hiện tượng bão gói tin (Flooding)
- **Trên màn hình `tcpdump` của `dhcprelay`:**
  Các gói tin `DHCPDISCOVER` và `DHCPOFFER` cuộn liên tục với tần suất dày đặc, làm ngập cổng mạng 67/68.
- **Lưu ý:** Giữ nguyên cửa sổ Yersinia đang bắn gói tin để sang Giai đoạn 3 kiểm chứng.

> **Điều kiện đạt checkwork:** Không có (Bước quan sát trực quan hiện tượng ngập lụt gói tin trên Relay).

---

## 4. GIAI ĐOẠN 3: Kiểm chứng ảnh hưởng của cuộc tấn công Flooding

### Bước 8: Kiểm chứng Client bị nghẽn khi xin cấp lại IP
**Trong lúc Yersinia vẫn đang bắn bão gói tin trên máy `attacker`**:
Chuyển sang cửa sổ terminal **`client`**:
```bash
# 1. Giải phóng (Release) địa chỉ IP hiện tại
dhclient -r eth0

# 2. Thử xin cấp phát lại IP trong lúc mạng đang bị bão gói tin
dhclient -v eth0
```

**Hiện tượng quan sát:**
- Do hàng đợi của Relay và Server bị nghẽn bởi hàng nghìn gói tin bão từ Attacker, gói tin của Client bị rớt (packet loss).
- Client phải **gửi lại nhiều lần (retransmissions)**:
  - `DHCPDISCOVER ... interval 3` không có phản hồi $\rightarrow$ phải gửi lại lần 2 (`interval 4`).
  - `DHCPREQUEST` cũng bị rớt $\rightarrow$ phải gửi lại lần 2.
  - Quá trình bắt tay bị trễ kéo dài tới 7–10 giây hoặc timeout hoàn toàn thay vì tức thì như ở Bước 3.

**Dừng cuộc tấn công Yersinia:**
Sau khi quan sát xong, quay lại cửa sổ `attacker` (trong màn hình Yersinia), bạn nhấn phím **`l`** (Cancel running attack) để dừng bắn gói tin, sau đó nhấn **`q`** để thoát hoàn toàn khỏi Yersinia.

> **Điều kiện đạt checkwork:** Mục tiêu **`client_congested`** chuyển sang **Y** khi thao tác giải phóng `dhclient -r` được ghi nhận trên máy `client`.

---

## 5. ĐÁNH GIÁ VÀ NỘP BÀI (CHECKWORK)

Tại terminal máy host (`student@LabtainerVMware`), gõ:
```bash
checkwork
```
Hệ thống sẽ tự động thu thập kết quả và hiển thị bảng chấm điểm:

| Mục tiêu chấm điểm | Trạng thái mong muốn | Mô tả chi tiết |
| :--- | :---: | :--- |
| **`client_has_ip`** | **Y** | Client đã xin cấp phát IP thành công ban đầu bằng `dhclient` |
| **`attacker_has_ip`** | **Y** | Attacker đã xin cấp phát IP thành công ban đầu bằng `dhclient` |
| **`flooding_attack`** | **Y** | Attacker đã kích hoạt tấn công DHCP Flooding bằng `yersinia` |
| **`client_congested`** | **Y** | Client giải phóng và thử xin cấp lại IP trong lúc bị Flooding (`dhclient -r && dhclient`) |