# Bài lab: DHCP Spoofing trong topology Labtainers cô lập

## 1. Mục tiêu và phạm vi

Bài lab minh họa cách một DHCP server giả trên mạng External có thể cấp cấu
hình mạng cho client khi DHCP server hợp lệ đã hết địa chỉ. Toàn bộ thao tác
chỉ thực hiện bên trong các container của bài lab. Không kết nối hoặc chạy các
công cụ này trên mạng thật, mạng trường học, mạng công cộng hay thiết bị ngoài
topology.

Bài này kiểm chứng **DHCP spoofing**. Nó không chứng minh attacker là
Man-in-the-Middle (MITM): attacker chỉ có một interface trong `EXTERNAL_NET`,
và gateway được cấp cho client là relay `10.10.0.1`, không phải attacker. Không
cấu hình IP forwarding, NAT hoặc kiểm tra SMB trong bài này.

## 2. Topology và các dải địa chỉ

| Container | Mạng | Địa chỉ | Vai trò |
| --- | --- | --- | --- |
| `dhcpserver` | `INTERNAL_NET` | `192.168.0.100` | DHCP server hợp lệ |
| `dhcprelay` | Cả hai mạng | `192.168.0.1`, `10.10.0.1` | Chuyển tiếp DHCP |
| `attacker` | `EXTERNAL_NET` | Lease hợp lệ trước; sau đó chạy server giả | Starvation và DHCP server giả |
| `client` | `EXTERNAL_NET` | Chưa xin IP trước khi pool hợp lệ cạn | Nhận lease để kiểm chứng |

DHCP server hợp lệ cấp các địa chỉ `10.10.0.100–10.10.0.130` (31 địa chỉ).
Server giả trên attacker dùng pool riêng `10.10.0.200–10.10.0.220`; pool này
không giao nhau với pool hợp lệ hoặc các địa chỉ hạ tầng. Cấu hình giả đặt
gateway là relay `10.10.0.1`.

Container attacker dùng image riêng được build từ image attacker hiện có và
cài thêm `isc-dhcp-server`. Ba image còn lại được dùng nguyên trạng.

## 3. Giai đoạn 1: Kiểm tra hạ tầng và lease ban đầu

### DHCP server

Trong terminal `dhcpserver`:

```bash
systemctl status dhcp-server-init.service --no-pager
pgrep -a dhcpd
ip route show
```

Xác nhận dịch vụ đang chạy trước khi tiếp tục.

### DHCP relay và giám sát lưu lượng

Trong terminal `dhcprelay`:

```bash
systemctl status dhcp-relay-init.service --no-pager
sysctl net.ipv4.ip_forward
pgrep -a dhcrelay
```

Mở một terminal `dhcprelay` để quan sát các gói DHCP:

```bash
sudo tcpdump -i any -n 'port 67 or port 68'
```

### Attacker nhận lease hợp lệ

Attacker có hai terminal dùng chung một container và một interface `eth0`.
Terminal 1 sẽ giữ `dhcpstarv` chạy; terminal 2 dùng để kiểm tra pool và quản
lý DHCP server giả.

Trên terminal attacker thứ nhất, trước khi chạy công cụ starvation:

```bash
sudo dhclient -v eth0
ip -4 addr show eth0
```

Xác nhận địa chỉ nhận được thuộc dải `10.10.0.100–10.10.0.130`. Trên
`dhcpserver`, có thể xem lease:

```bash
sudo grep -E 'lease 10\.10\.0\.|binding state' /var/lib/dhcp/dhcpd.leases
```

Không yêu cầu client xin IP ở giai đoạn này; client cần chưa có lease để lần
xin IP sau khi pool hợp lệ cạn được quan sát rõ ràng.

## 4. Giai đoạn 2: Giữ starvation chạy liên tục

Trên terminal attacker thứ nhất, chạy công cụ trên `eth0` thuộc mạng
`EXTERNAL_NET`:

```bash
sudo dhcpstarv -i eth0
```

**Để terminal này mở và không nhấn Ctrl+C.** Trong khi tiến trình vẫn chạy,
dùng terminal attacker thứ hai để thao tác với server giả. Tại `dhcpserver`,
kiểm tra số lease active:

```bash
sudo grep -c 'binding state active;' /var/lib/dhcp/dhcpd.leases
```

Pool có 31 địa chỉ. Dùng số đếm để theo dõi tiến độ, sau đó xác nhận DHCP
server đã báo hết lease khả dụng:

```bash
sudo grep 'no free leases' /var/log/syslog | tail
```

Chỉ tiếp tục khi log server có dòng báo `network 10.10.0.0/24: no free leases`.
Một số địa chỉ có thể bị ISC DHCP đánh dấu `abandoned`; vì vậy số dòng
`binding state active;` đôi khi thấp hơn 31 dù pool đã không còn lease khả
dụng. Chỉ chạy `dhcpstarv` không đủ để chứng minh pool đã cạn.

Giữ `dhcpstarv` chạy sau khi server báo hết lease để công cụ tiếp tục gửi yêu
cầu trong thời gian thực hành.

## 5. Giai đoạn 3: Khởi chạy DHCP server giả ở terminal thứ hai

Trong khi `dhcpstarv` vẫn chạy ở terminal attacker thứ nhất, dùng terminal
attacker thứ hai để xác nhận package và cấu hình server giả có sẵn:

```bash
dpkg -s isc-dhcp-server | grep '^Status:'
sudo dhcpd -t -4 -cf /etc/dhcp/dhcpd-spoofing.conf
```

Server giả được cấu hình chỉ cấp lease cho MAC cố định của container `client`
(`02:42:0a:0a:00:32`). Nhờ đó các MAC ngẫu nhiên do `dhcpstarv` tạo ra không
tiêu thụ pool riêng của server giả, trong khi client của bài lab vẫn có thể
nhận lease. Lệnh kiểm tra cấu hình cần kết thúc thành công trước khi khởi chạy
server.
Khởi chạy server giả ở foreground để có thể quan sát log:

```bash
sudo dhcpd -4 -f -d \
  -cf /etc/dhcp/dhcpd-spoofing.conf \
  -lf /var/lib/dhcp/dhcpd-spoofing.leases \
  -pf /run/dhcpd-spoofing.pid \
  eth0 2>&1 | sudo tee /var/log/dhcp-spoofing-server.log
```

Giữ tiến trình này chạy trong khi client xin IP. Khi server khởi động đúng,
log có dòng `Listening on LPF/eth0/`. Nếu không có, đọc lỗi hiển thị trong
terminal và không tiếp tục với giả định server đang hoạt động.

## 6. Giai đoạn 4: Client xin IP và xác minh kết quả

Chỉ sau khi pool hợp lệ đã được xác nhận cạn và log attacker cho thấy server
giả đang lắng nghe, chuyển sang terminal `client`. Giữ cả `dhcpstarv` trên
attacker terminal thứ nhất và DHCP server giả trên terminal thứ hai chạy trong
thời gian client xin IP:

```bash
sudo dhclient -1 -v eth0 2>&1 | tee /home/ubuntu/dhcp-spoofing-client.log
```

Kiểm tra lease và thông số mạng thực nhận:

```bash
ip -4 addr show eth0
ip route show
sudo grep -E 'fixed-address|option routers|option domain-name-servers' \
  /var/lib/dhcp/dhclient.leases
```

Nếu client được server giả phục vụ, lease phải nằm trong `10.10.0.200–10.10.0.220`.
Log của attacker phải ghi nhận `DHCPACK` cho địa chỉ thuộc dải đó. Đây là bằng
chứng của lease cấp bởi server giả; việc chỉ thấy lệnh đã chạy hoặc server đã
khởi động không đủ để kết luận client nhận được lease.

Nếu client không nhận lease, không kết luận spoofing thành công. Kiểm tra lại
số lease hợp lệ, log của server giả, cấu hình interface và lưu lượng trên
relay. Một pool chưa cạn, lease đã hết hạn hoặc server giả không lắng nghe
đúng interface đều có thể làm thay đổi kết quả.

Sau khi lưu bằng chứng, dừng server giả bằng **Ctrl+C** tại terminal attacker
thứ hai, rồi dừng `dhcpstarv` bằng **Ctrl+C** tại terminal attacker thứ nhất.

## 7. Checkwork và tiêu chí đánh giá

Trên host Labtainer, dừng lab và chấm kết quả:

```bash
stoplab dhcp-spoofing
checkwork dhcp-spoofing
```

| Mục tiêu | Bằng chứng được kiểm tra |
| --- | --- |
| `attacker_has_ip` | Lease của attacker thuộc pool DHCP hợp lệ. |
| `pool_exhausted` | Log của server hợp lệ báo `network 10.10.0.0/24: no free leases`. |
| `rogue_server_listening` | Log ghi nhận DHCP server giả đã lắng nghe trên `eth0`. |
| `client_received_rogue_lease` | Lease của client nằm trong pool riêng `10.10.0.200–10.10.0.220`. |
| `rogue_server_served_client` | Log server giả ghi nhận DHCPACK trong pool giả. |

Hai mục tiêu cuối kiểm chứng riêng lease ở client và phản hồi ACK từ server
giả. Mục tiêu `pool_exhausted` dựa vào thông báo của DHCP server, không dựa
vào shell history, số lệnh chạy hay chỉ việc đã khởi chạy `dhcpstarv`.

Để chạy lại từ trạng thái sạch:

```bash
labtainer -r dhcp-spoofing
```

## Ghi chú triển khai image attacker (giảng viên)

Attacker dùng Dockerfile riêng `dockerfiles/Dockerfile.dhcp-spoofing.attacker.student`
và tên image Labtainers `dhcp-spoofing.attacker.student`. Labtainers sẽ dùng
Dockerfile này khi build image của lab. Có thể build trước trên host Labtainers:

```bash
cd /home/student/labtainer/trunk
docker build --pull=false --build-arg registry=huynguyen1324 \
  -f labs/dhcp-spoofing/dockerfiles/Dockerfile.dhcp-spoofing.attacker.student \
  -t dhcp-spoofing.attacker.student:latest \
  labs/dhcp-spoofing
```

Image được build cục bộ; để dùng trên host khác, cần publish theo quy trình
Labtainers của giảng viên dưới registry đã khai báo trong `start.config`.
