#!/usr/bin/env python3

import json
import numpy as np
from pathlib import Path

from common_dsss import (
    read_wav_mono,
    write_wav_mono,
    bytes_to_bits,
    int_to_32bits,
    generate_pn,
    spread_bits
)


COVER_WAV = "cover.wav"
MESSAGE_TXT = "message.txt"
OUTPUT_WAV = "stego_weak_seed.wav"
PUBLIC_PARAMS = "public_params.json"
SECRET_PARAMS = "secret_params.json"

# Weak seed: attacker can brute-force this range.
SECRET_SEED = 137

CHIPS_PER_BIT = 512
EMBED_AMPLITUDE = 0.015


def main():
    sample_rate, cover = read_wav_mono(COVER_WAV)
    message = Path(MESSAGE_TXT).read_bytes()

    payload_bits = bytes_to_bits(message)
    length_bits = int_to_32bits(len(message))
    all_bits = np.concatenate([length_bits, payload_bits])

    n_bits = len(all_bits)
    n_chips = n_bits * CHIPS_PER_BIT

    if n_chips > len(cover):
        raise ValueError("Cover audio is too short.")

    pn = generate_pn(SECRET_SEED, n_chips)
    watermark = spread_bits(all_bits, pn, CHIPS_PER_BIT)

    stego = cover.copy()
    stego[:n_chips] = stego[:n_chips] + EMBED_AMPLITUDE * watermark

    write_wav_mono(OUTPUT_WAV, sample_rate, stego)

    public_params = {
        "algorithm": "DSSS",
        "chips_per_bit": CHIPS_PER_BIT,
        "n_bits": int(n_bits),
        "n_chips": int(n_chips),
        "message_length_bytes": len(message),
        "embed_amplitude": EMBED_AMPLITUDE,
        "sample_rate": sample_rate,
        "seed_status": "hidden"
    }

    secret_params = {
        "secret_seed": SECRET_SEED
    }

    Path(PUBLIC_PARAMS).write_text(
        json.dumps(public_params, indent=2),
        encoding="utf-8"
    )

    Path(SECRET_PARAMS).write_text(
        json.dumps(secret_params, indent=2),
        encoding="utf-8"
    )

    print("[OK] Created stego_weak_seed.wav")
    print("[OK] Created public_params.json")
    print("[OK] Created secret_params.json")
    print("[INFO] A weak seed was used for this educational lab.")


if __name__ == "__main__":
    main()
