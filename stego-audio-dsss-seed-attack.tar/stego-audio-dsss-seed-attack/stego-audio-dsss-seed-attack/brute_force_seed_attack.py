#!/usr/bin/env python3

import json
from pathlib import Path

from common_dsss import (
    read_wav_mono,
    generate_pn,
    despread_bits,
    bits32_to_int,
    bits_to_bytes,
    is_readable_text
)


STEGO_WAV = "stego_weak_seed.wav"
PUBLIC_PARAMS = "public_params.json"

OUTPUT_MESSAGE = "attacker_extracted_message.txt"
OUTPUT_REPORT = "seed_attack_report.txt"

START_SEED = 0
END_SEED = 999


def try_extract_with_seed(audio, seed, chips_per_bit, n_bits, n_chips):
    received = audio[:n_chips]
    pn = generate_pn(seed, n_chips)

    bits = despread_bits(received, pn, chips_per_bit, n_bits)

    message_length = bits32_to_int(bits[:32])
    max_possible_bytes = max(0, (n_bits - 32) // 8)

    if message_length <= 0 or message_length > max_possible_bytes:
        return None

    message_bits = bits[32:32 + message_length * 8]
    message = bits_to_bytes(message_bits)

    readable, text = is_readable_text(message)

    if readable:
        return text

    return None


def main():
    public_params = json.loads(Path(PUBLIC_PARAMS).read_text())

    chips_per_bit = int(public_params["chips_per_bit"])
    n_bits = int(public_params["n_bits"])
    n_chips = int(public_params["n_chips"])

    sample_rate, audio = read_wav_mono(STEGO_WAV)

    found_seed = None
    found_message = None
    attempts = 0

    for seed in range(START_SEED, END_SEED + 1):
        attempts += 1

        result = try_extract_with_seed(
            audio=audio,
            seed=seed,
            chips_per_bit=chips_per_bit,
            n_bits=n_bits,
            n_chips=n_chips
        )

        if result is not None:
            found_seed = seed
            found_message = result
            break

    report_lines = []
    report_lines.append("DSSS Weak Seed Brute Force Attack Report")
    report_lines.append("=" * 55)
    report_lines.append(f"Seed search range: {START_SEED} to {END_SEED}")
    report_lines.append(f"Total attempts: {attempts}")
    report_lines.append("")

    if found_seed is not None:
        report_lines.append("ATTACK_RESULT: SUCCESS")
        report_lines.append(f"Recovered seed: {found_seed}")
        report_lines.append(f"Recovered message: {found_message}")

        Path(OUTPUT_MESSAGE).write_text(found_message, encoding="utf-8")
    else:
        report_lines.append("ATTACK_RESULT: FAILED")
        report_lines.append("No readable message found in this seed range.")

        Path(OUTPUT_MESSAGE).write_text("", encoding="utf-8")

    report = "\n".join(report_lines)

    Path(OUTPUT_REPORT).write_text(report, encoding="utf-8")

    print(report)
    print("[OK] Report saved to", OUTPUT_REPORT)


if __name__ == "__main__":
    main()
