#!/usr/bin/env python3

import wave
import numpy as np

SAMPLE_RATE = 44100
DURATION_SECONDS = 12
OUTPUT_FILE = "cover.wav"


def main():
    t = np.arange(int(SAMPLE_RATE * DURATION_SECONDS)) / SAMPLE_RATE

    signal = (
        0.18 * np.sin(2 * np.pi * 440 * t) +
        0.08 * np.sin(2 * np.pi * 880 * t) +
        0.04 * np.sin(2 * np.pi * 1320 * t)
    )

    samples = np.int16(np.clip(signal, -1.0, 1.0) * 32767)

    with wave.open(OUTPUT_FILE, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(samples.tobytes())

    print("[OK] Created cover.wav")


if __name__ == "__main__":
    main()
