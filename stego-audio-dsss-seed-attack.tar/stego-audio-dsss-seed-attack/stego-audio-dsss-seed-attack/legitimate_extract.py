#!/usr/bin/env python3

import json
from pathlib import Path

from common_dsss import (
    read_wav_mono,
    generate_pn,
    despread_bits,
    bits32_to_int,
    bits_to_bytes
)


STEGO_WAV = "stego_weak_seed.wav"
PUBLIC_PARAMS = "public_params.json"
SECRET_PARAMS = "secret_params.json"
OUTPUT_TXT = "legitimate_extracted_message.txt"


def main():
    public_params = json.loads(Path(PUBLIC_PARAMS).read_text())
    secret_params = json.loads(Path(SECRET_PARAMS).read_text())

    seed = int(secret_params["secret_seed"])
    chips_per_bit = int(public_params["chips_per_bit"])
    n_bits = int(public_params["n_bits"])
    n_chips = int(public_params["n_chips"])

    sample_rate, audio = read_wav_mono(STEGO_WAV)

    received = audio[:n_chips]
    pn = generate_pn(seed, n_chips)

    bits = despread_bits(received, pn, chips_per_bit, n_bits)

    message_length = bits32_to_int(bits[:32])
    message_bits = bits[32:32 + message_length * 8]
    message = bits_to_bytes(message_bits)

    Path(OUTPUT_TXT).write_bytes(message)

    print("[OK] Legitimate extraction completed")
    print("[OK] Saved to", OUTPUT_TXT)

    try:
        print("[MESSAGE]", message.decode("utf-8"))
    except UnicodeDecodeError:
        print("[MESSAGE] Non-UTF8 output")


if __name__ == "__main__":
    main()
