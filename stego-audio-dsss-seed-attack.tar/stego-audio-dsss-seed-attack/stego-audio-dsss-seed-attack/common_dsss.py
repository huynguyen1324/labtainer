#!/usr/bin/env python3

import wave
import numpy as np


def read_wav_mono(path):
    with wave.open(path, "rb") as wf:
        channels = wf.getnchannels()
        sample_width = wf.getsampwidth()
        sample_rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sample_width != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0

    if channels > 1:
        audio = audio.reshape(-1, channels).mean(axis=1)

    return sample_rate, audio


def write_wav_mono(path, sample_rate, audio):
    samples = np.int16(np.clip(audio, -1.0, 1.0) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(samples.tobytes())


def bytes_to_bits(data):
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))


def bits_to_bytes(bits):
    bits = np.asarray(bits, dtype=np.uint8)
    n = (len(bits) // 8) * 8
    return np.packbits(bits[:n]).tobytes()


def int_to_32bits(value):
    return np.array(
        [(value >> i) & 1 for i in range(31, -1, -1)],
        dtype=np.uint8
    )


def bits32_to_int(bits):
    value = 0
    for bit in bits[:32]:
        value = (value << 1) | int(bit)
    return value


def generate_pn(seed, n_chips):
    rng = np.random.default_rng(int(seed))
    return rng.choice(
        np.array([-1.0, 1.0], dtype=np.float32),
        size=int(n_chips)
    )


def spread_bits(bits, pn, chips_per_bit):
    symbols = np.where(bits == 1, 1.0, -1.0).astype(np.float32)
    expanded = np.repeat(symbols, chips_per_bit)
    return expanded * pn[:len(expanded)]


def despread_bits(received, pn, chips_per_bit, n_bits):
    received = received[:n_bits * chips_per_bit]
    pn = pn[:n_bits * chips_per_bit]

    output_bits = []

    for i in range(n_bits):
        start = i * chips_per_bit
        end = start + chips_per_bit

        corr = float(np.dot(received[start:end], pn[start:end]))

        if corr >= 0:
            output_bits.append(1)
        else:
            output_bits.append(0)

    return np.array(output_bits, dtype=np.uint8)


def is_readable_text(data):
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return False, ""

    if len(text) == 0:
        return False, ""

    printable = sum(1 for c in text if c.isprintable() or c in "\n\r\t")
    ratio = printable / len(text)

    if ratio > 0.9:
        return True, text

    return False, text
