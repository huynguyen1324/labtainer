# HƯỚNG DẪN KIỂM THỬ THỦ CÔNG (TESTING GUIDE)
## BÀI LAB: DHCP FLOODING QUA DHCP RELAY (KIẾN TRÚC DUAL-SUBNET)

> **LƯU Ý:**
> - Tài liệu này cung cấp toàn bộ câu lệnh thực tế để bạn tự tay thực hiện trên từng terminal.
> - Agent không tự động chạy bất kỳ lệnh kiểm thử hay phát sinh lưu lượng tấn công nào.

---

## A. BƯỚC 1: KHỞI ĐỘNG LAB & BASELINE KIỂM TRA MÔI TRƯỜNG BÌNH THƯỜNG

### 1. Khởi động bài lab trên máy Host
Tại terminal máy host (`~/labtainer/labtainer-student`):
```bash
labtainer dhcp-flooding -r
```
*4 cửa sổ terminal sẽ xuất hiện: `dhcpserver`, `dhcprelay`, `attacker`, và `client`.*

---

### 2. Khởi động DHCP Server (`dhcpserver`)
Trên terminal **`dhcpserver`**:
```bash
# 1. Chay script khoi dong DHCP Server va them route den mang External
sudo /usr/local/bin/start-dhcp.sh

# 2. Bat giam sat goi tin DHCP tren card eth0 (INTERNAL_NET)
sudo tcpdump -i eth0 -n -vv "(port 67 or port 68)"
```
*(Để nguyên cửa sổ này để xem log bắt gói tin thời gian thực).*

---

### 3. Khởi động DHCP Relay (`dhcprelay`)
Trên terminal **`dhcprelay`**:
```bash
# 1. Chay script kich hoat chuyen tiep DHCP giua eth1 (External) va eth0 (Internal)
sudo /usr/local/bin/start-relay.sh

# 2. Bat giam sat goi tin DHCP tren tat ca cac giao dien
sudo tcpdump -i any -n "(port 67 or port 68)"
```
*(Để nguyên cửa sổ này để theo dõi tiến trình chuyển tiếp gói tin).*

---

### 4. Kiểm tra cấp phát IP trên Client hợp lệ (`client`)
Trên terminal **`client`**:
```bash
# Xin cap phat IP tu DHCP Server thong qua DHCP Relay
sudo /usr/local/bin/request-ip.sh
```
> **Kết quả mong đợi khi bình thường:**
> - Trên `client`: Nhận được địa chỉ IP trong dải `10.10.0.100` – `10.10.0.130`, Default Gateway là `10.10.0.1`.
> - Trên `dhcprelay`: Bắt được gói broadcast từ Client trên `eth1`, gán trường `giaddr = 10.10.0.1` và chuyển tiếp unicast sang `192.168.0.100` trên `eth0`.
> - Trên `dhcpserver`: Nhận được gói tin qua Relay, cấp Offer và lưu lease:
>   ```bash
>   cat /var/lib/dhcp/dhcpd.leases
>   ```

---

## B. BƯỚC 2: THỬ NGHIỆM TẤN CÔNG DHCP FLOODING

Kẻ tấn công (`attacker`) nằm cùng mạng `EXTERNAL_NET` với Client, gửi ồ ạt các gói tin `DHCP Discover` với hàng trăm MAC giả mạo.

### Trên terminal `attacker`:
Bạn có thể chọn 1 trong 2 phương án:

#### Phương án 1 (Scapy Script — Có giới hạn số lượng và độ trễ an toàn):
```bash
# Gui 100 goi DHCP Discover vao mang EXTERNAL_NET, delay 20ms:
sudo /usr/local/bin/dhcp-flood.py -i eth0 -c 100 -d 0.02
```

#### Phương án 2 (Yersinia):
```bash
sudo yersinia dhcp -attack 1 -interface eth0
```
*(Bấm **`Ctrl + C`** để dừng khi muốn kết thúc tấn công).*

---

### Quan sát hiện tượng trong lúc diễn ra Flooding:
1. **Trên `dhcprelay`:**
   - Hàng loạt gói tin Discover dồn dập đến cổng `eth1`. Tiến trình `dhcrelay` liên tục đóng gói lại và chuyển tiếp sang máy chủ `dhcpserver`.
2. **Trên `dhcpserver`:**
   - Máy chủ bị quá tải hàng đợi xử lý gói tin UDP 67 từ Relay gửi tới, liên tục tính toán phản hồi Offer.
   - Kiểm tra tải hệ thống:
     ```bash
     top
     ```
3. **Thử nghiệm trên `client` (trong khi flood đang chạy):**
   ```bash
   sudo dhclient -r eth0 && sudo dhclient -v eth0
   ```
   - **Hiện tượng cần ghi nhận:** Quá trình xin cấp phát IP của Client bị trễ (delay) rõ rệt hoặc bị timeout do hàng đợi của cả DHCP Relay và DHCP Server đều bị ngập lụt bởi lưu lượng tấn công.

---

## C. BƯỚC 3: KHÔI PHỤC VÀ KẾT THÚC BÀI LAB

1. **Dừng tấn công trên `attacker`:**
   - Bấm `Ctrl + C` hoặc chạy:
     ```bash
     sudo killall -9 yersinia 2>/dev/null || true
     ```
2. **Kiểm tra lại trên `client` sau khi dừng tấn công:**
   ```bash
   sudo /usr/local/bin/request-ip.sh
   ```
   Client lập tức nhận lại IP nhanh chóng và ổn định.
3. **Dừng bài lab trên máy Host:**
   ```bash
   stoplab dhcp-flooding
   ```
