# HƯỚNG DẪN THỰC HÀNH BÀI LAB: DHCP FLOODING (QUA DHCP RELAY)

---

## 1. Sơ đồ mạng và phân bổ IP (Topology)

| Máy (Container) | Mạng kết nối | Địa chỉ IP | Vai trò |
| :--- | :--- | :--- | :--- |
| **`dhcpserver`** | `INTERNAL_NET` (192.168.0.0/24) | `192.168.0.100` (Tĩnh) | Cung cấp IP động (Pool: `10.10.0.100 - 10.10.0.130`) |
| **`dhcprelay`** | Nối cả 2 mạng | eth0: `192.168.0.1`<br>eth1: `10.10.0.1` | Chuyển tiếp DHCP giữa External $\leftrightarrow$ Internal |
| **`client`** | `EXTERNAL_NET` (10.10.0.0/24) | *Chưa có IP* (Dynamic) | Máy nạn nhân xin cấp IP động qua Relay |
| **`attacker`** | `EXTERNAL_NET` (10.10.0.0/24) | *Chưa có IP* (Dynamic) | Máy tấn công tạo bão gói tin DHCP Discover bằng `yersinia` |

---

## 2. GIAI ĐOẠN 1: Khởi động dịch vụ và cấp phát IP bình thường

### Bước 1: Cấu hình và khởi động DHCP Server
Trên cửa sổ terminal **`dhcpserver`**:
```bash
# 1. Thêm định tuyến quay về mạng External (10.10.0.0/24) thông qua Relay (192.168.0.1)
ip route add 10.10.0.0/24 via 192.168.0.1 dev eth0

# 2. Đảm bảo file cơ sở dữ liệu leases tồn tại
touch /var/lib/dhcp/dhcpd.leases

# 3. Khởi động dịch vụ ISC DHCP Server lắng nghe trên card eth0
dhcpd -4 -cf /etc/dhcp/dhcpd.conf eth0

# 4. Kiểm tra tiến trình DHCP Server đang chạy
pgrep -a dhcpd
```
> [!NOTE]
> DHCP Server cần lệnh `ip route add` để biết đường gửi các gói tin `DHCPOFFER` và `DHCPACK` quay ngược về cho DHCP Relay.

---

### Bước 2: Cấu hình và khởi động DHCP Relay
Trên cửa sổ terminal **`dhcprelay`**:
```bash
# 1. Bật tính năng chuyển tiếp gói tin (IP Forwarding) trong Linux kernel
sysctl -w net.ipv4.ip_forward=1

# 2. Khởi động dịch vụ DHCP Relay lắng nghe trên eth1 (External) và eth0 (Internal), chuyển tiếp về Server 192.168.0.100
dhcrelay -4 -i eth0 -i eth1 192.168.0.100

# 3. Giám sát các gói tin DHCP để quan sát lưu lượng bắt tay 4 bước
tcpdump -i any -n port 67 or port 68
```

---

### Bước 3: Máy Client xin cấp phát IP qua Relay
Trên cửa sổ terminal **`client`**:
```bash
# 1. Kiểm tra ban đầu: Card mạng chưa có địa chỉ IPv4
ip addr show eth0

# 2. Thực hiện xin cấp phát IP động bằng lệnh dhclient
dhclient -v eth0
```
> [!TIP]
> - Máy `client` sẽ hoàn thành bắt tay 4 bước: `DHCPDISCOVER` $\rightarrow$ `DHCPOFFER` $\rightarrow$ `DHCPREQUEST` $\rightarrow$ `DHCPACK` chỉ trong tích tắc (< 0.2s).
> - Thao tác này hoàn thành mục tiêu **`client_has_ip`**.

Kiểm tra lại thông tin IP và Default Gateway nhận được:
```bash
ip addr show eth0
ip route show
```

---

### Bước 4: Máy Attacker xin cấp phát IP ban đầu
Trước khi tấn công, Attacker cũng cần có IP trong mạng External:
Trên cửa sổ terminal **`attacker`**:
```bash
# Xin cấp phát IP động từ DHCP Server
dhclient -v eth0
```
> [!TIP]
> Máy `attacker` sẽ nhận IP tiếp theo trong dải (ví dụ `10.10.0.101`). Thao tác này hoàn thành mục tiêu **`attacker_has_ip`**.

---

### Bước 5: Kiểm tra trạng thái cấp phát trên DHCP Server
Trên cửa sổ terminal **`dhcpserver`**:
```bash
# Xem các hợp đồng cấp phát IP (leases) đang hoạt động
cat /var/lib/dhcp/dhcpd.leases
```
*Bạn sẽ thấy hai bản ghi lease cấp phát `10.10.0.100` cho Client và `10.10.0.101` cho Attacker.*

---

## 3. GIAI ĐOẠN 2: Thực hiện tấn công DHCP Flooding bằng `yersinia`

**Mục tiêu:** Attacker phát tán bão gói tin `DHCP Discover` với tốc độ cao nhằm làm nghẽn băng thông và quá tải hàng đợi của Relay / Server.

### Bước 6: Khởi chạy tấn công từ Attacker bằng Yersinia
Trên cửa sổ terminal **`attacker`**:
```bash
yersinia -I
```

**Thao tác trong giao diện ncurses của Yersinia:**
1. Nhấn phím **`g`** (chọn giao thức).
2. Dùng phím mũi tên di chuyển chọn dòng **`DHCP`**, nhấn **`Enter`**.
3. Nhấn phím **`x`** (mở danh sách kiểu tấn công - Attack menu).
4. Chọn mode **`1: sending DISCOVER packet`**, nhấn **`Enter`**.

*(Lúc này, Yersinia phát sinh hàng nghìn gói tin DHCP Discover ra card `eth0` với tốc độ cực nhanh. Thao tác này hoàn thành mục tiêu **`flooding_attack`**).*

---

### Bước 7: Quan sát hiện tượng bão gói tin (Flooding)
- **Trên màn hình `tcpdump` của `dhcprelay`:**
  Các gói tin `DHCPDISCOVER` và `DHCPOFFER` cuộn liên tục với tần suất dày đặc, làm ngập cổng mạng 67/68.
- **Lưu ý:** Giữ nguyên cửa sổ Yersinia đang bắn gói tin để sang Giai đoạn 3 kiểm chứng.

---

## 4. GIAI ĐOẠN 3: Kiểm chứng ảnh hưởng của cuộc tấn công Flooding

### Bước 8: Kiểm chứng Client bị nghẽn khi xin cấp lại IP
**Trong lúc Yersinia vẫn đang bắn bão gói tin trên máy `attacker`**:
Chuyển sang cửa sổ terminal **`client`**:
```bash
# 1. Giải phóng (Release) địa chỉ IP hiện tại
dhclient -r eth0

# 2. Thử xin cấp phát lại IP trong lúc mạng đang bị bão gói tin
dhclient -v eth0
```

**Hiện tượng quan sát:**
- Do hàng đợi của Relay và Server bị nghẽn bởi hàng nghìn gói tin bão từ Attacker, gói tin của Client bị rớt (packet loss).
- Client phải **gửi lại nhiều lần (retransmissions)**:
  - `DHCPDISCOVER ... interval 3` không có phản hồi $\rightarrow$ phải gửi lại lần 2 (`interval 4`).
  - `DHCPREQUEST` cũng bị rớt $\rightarrow$ phải gửi lại lần 2.
  - Quá trình bắt tay bị trễ kéo dài tới 7–10 giây hoặc timeout hoàn toàn thay vì tức thì như ở Bước 3.
- Thao tác này hoàn thành mục tiêu **`client_congested`**!

**Dừng cuộc tấn công Yersinia:**
Sau khi quan sát xong, quay lại cửa sổ `attacker` (trong màn hình Yersinia), bạn nhấn phím **`l`** (Cancel running attack) để dừng bắn gói tin, sau đó nhấn **`q`** để thoát hoàn toàn khỏi Yersinia.

---

## 5. ĐÁNH GIÁ VÀ NỘP BÀI (CHECKWORK)

Tại terminal máy host (`student@LabtainerVMware`), gõ:
```bash
checkwork
```
Hệ thống sẽ tự động thu thập kết quả và hiển thị bảng chấm điểm:

| Mục tiêu chấm điểm | Trạng thái mong muốn | Mô tả chi tiết |
| :--- | :---: | :--- |
| **`client_has_ip`** | **Y** | Client đã xin cấp phát IP thành công ban đầu bằng `dhclient` |
| **`attacker_has_ip`** | **Y** | Attacker đã xin cấp phát IP thành công ban đầu bằng `dhclient` |
| **`flooding_attack`** | **Y** | Attacker đã kích hoạt tấn công DHCP Flooding bằng `yersinia` |
| **`client_congested`** | **Y** | Client giải phóng và thử xin cấp lại IP trong lúc bị Flooding (`dhclient -r && dhclient`) |