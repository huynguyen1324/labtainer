# BÀI LAB: DHCP FLOODING TRÊN MÔ HÌNH DUAL-SUBNET VỚI DHCP RELAY

## 1. Giới thiệu tổng quan
Bài lab mô phỏng cuộc tấn công **DHCP Flooding** trong kiến trúc mạng doanh nghiệp gồm **2 Subnet tách biệt** được nối qua một **DHCP Relay**:
- **`INTERNAL_NET` (192.168.0.0/24):** Vùng mạng máy chủ nội bộ chứa máy chủ **DHCP Server** (`192.168.0.100`).
- **`EXTERNAL_NET` (10.10.0.0/24):** Vùng mạng máy trạm chứa **Ubuntu Client** (`10.10.0.50`) và **Kali Attacker** (`10.10.0.20`).
- **`DHCP Relay` (Router đa card mạng):** Nằm giữa 2 mạng, chuyển tiếp broadcast DHCP từ `EXTERNAL_NET` sang unicast tới DHCP Server tại `INTERNAL_NET`.

---

## 2. Bảng phân bổ Topology & IP

| Container | Vai trò | Subnet kết nối | IP tĩnh hạ tầng | Địa chỉ MAC | Image chuẩn hóa |
|---|---|---|---|---|---|
| **`dhcpserver`** | DHCP Server | `INTERNAL_NET` | `192.168.0.100` | `02:42:c0:a8:00:64` | `labtainer-dhcp-server:1.0` |
| **`dhcprelay`** | DHCP Relay Router | `INTERNAL_NET`<br>`EXTERNAL_NET` | `192.168.0.1`<br>`10.10.0.1` | `02:42:c0:a8:00:01`<br>`02:42:0a:0a:00:01` | `labtainer-dhcp-relay:1.0` |
| **`attacker`** | Kẻ tấn công | `EXTERNAL_NET` | `10.10.0.20` | `02:42:0a:0a:00:14` | `labtainer-kali-attacker:1.0` |
| **`client`** | Máy trạm hợp lệ | `EXTERNAL_NET` | `10.10.0.50` (init) | `02:42:0a:0a:00:32` | `labtainer-ubuntu-client:1.0` |

- **DHCP Dynamic Pool cấp phát cho EXTERNAL_NET:** `10.10.0.100` – `10.10.0.130` (31 IP hữu hạn, không trùng IP hạ tầng).

---

## 3. Lệnh khởi động & Dừng bài lab trên Host

Mở terminal trên máy host tại thư mục `~/labtainer/labtainer-student`:

### 3.1. Khởi động bài lab
```bash
labtainer dhcp-flooding -r
```
*(Cờ `-r` đảm bảo xóa sạch phiên cũ và khởi động 4 cửa sổ terminal mới).*

### 3.2. Dừng bài lab
```bash
stoplab dhcp-flooding
```

---

## 4. Tài liệu kiểm thử chi tiết
Vui lòng tham khảo file [`TESTING_GUIDE.md`](file:///home/student/labtainer/trunk/labs/dhcp-flooding/docs/TESTING_GUIDE.md) để thực hiện kiểm thử thủ công từng bước:
- Khởi động dịch vụ Server & Relay.
- Baseline xin IP qua Relay.
- Thử nghiệm tấn công DHCP Flooding từ Attacker vào mạng External.
- Khôi phục và đánh giá kết quả.
