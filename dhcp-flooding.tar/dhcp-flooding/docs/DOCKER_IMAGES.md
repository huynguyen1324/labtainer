# BỘ DOCKER IMAGE CHUẨN HÓA DÙNG CHUNG (STANDARDIZED DOCKER IMAGES)
## CHO HỆ THỐNG CÁC BÀI LAB AN NINH MẠNG TRÊN LABTAINERS

Tài liệu này chuẩn hóa và ghi lại thông số chi tiết của 4 Docker image dùng chung, được thiết kế để tái sử dụng xuyên suốt giữa nhiều bài lab an ninh mạng độc lập (DHCP Flooding, DHCP Starvation, DHCP Spoofing, DHCP Relay, Monitoring, v.v.).

---

## 1. Bảng danh mục Image chuẩn hóa

| Tên Logic | Tên Docker Image thực tế | Tag / Phiên bản | Base Image | Danh sách gói phần mềm chính | Vai trò / Chức năng |
|---|---|---|---|---|---|
| **Kali Attacker** | `labtainer-kali-attacker` | `1.0` | `labtainers/labtainer.network.ssh2` (Ubuntu 20.04) | `yersinia`, `python3-scapy`, `tcpdump`, `tshark`, `nmap`, `net-tools`, `iputils-ping`, `isc-dhcp-client` | Máy tấn công chuyên dụng (Flooding, Starvation, Spoofing, Quét mạng) |
| **DHCP Server** | `labtainer-dhcp-server` | `1.0` | `labtainers/labtainer.network.ssh2` (Ubuntu 20.04) | `isc-dhcp-server` (dhcpd 4.4.1), `dnsmasq`, `tcpdump`, `net-tools`, `procps` | Máy chủ cấp phát IP động, quản lý scope/pool/lease |
| **DHCP Relay** | `labtainer-dhcp-relay` | `1.0` | `labtainers/labtainer.network.ssh2` (Ubuntu 20.04) | `isc-dhcp-relay` (dhcrelay 4.4.1), `iptables`, `iproute2`, `tcpdump`, `net-tools` | Router / Gateway đa card mạng chuyển tiếp DHCP giữa các subnet |
| **Ubuntu Client** | `labtainer-ubuntu-client` | `1.0` | `labtainers/labtainer.network.ssh2` (Ubuntu 20.04) | `isc-dhcp-client` (`dhclient`), `tcpdump`, `dnsutils`, `iputils-ping`, `net-tools` | Máy trạm nạn nhân / Client hợp lệ xin IP qua DHCP |

---

## 2. Vị trí lưu trữ Dockerfile & Cách build lại độc lập

Tất cả Dockerfile chuẩn hóa được đặt tại thư mục dùng chung:
- Attacker: [`/home/student/labtainer/dockerfiles-common/labtainer-kali-attacker/Dockerfile`](file:///home/student/labtainer/dockerfiles-common/labtainer-kali-attacker/Dockerfile)
- DHCP Server: [`/home/student/labtainer/dockerfiles-common/labtainer-dhcp-server/Dockerfile`](file:///home/student/labtainer/dockerfiles-common/labtainer-dhcp-server/Dockerfile)
- DHCP Relay: [`/home/student/labtainer/dockerfiles-common/labtainer-dhcp-relay/Dockerfile`](file:///home/student/labtainer/dockerfiles-common/labtainer-dhcp-relay/Dockerfile)
- Ubuntu Client: [`/home/student/labtainer/dockerfiles-common/labtainer-ubuntu-client/Dockerfile`](file:///home/student/labtainer/dockerfiles-common/labtainer-ubuntu-client/Dockerfile)

### Lệnh build độc lập trên máy mới:
```bash
docker build -t labtainer-kali-attacker:1.0 /home/student/labtainer/dockerfiles-common/labtainer-kali-attacker
docker build -t labtainer-dhcp-server:1.0 /home/student/labtainer/dockerfiles-common/labtainer-dhcp-server
docker build -t labtainer-dhcp-relay:1.0 /home/student/labtainer/dockerfiles-common/labtainer-dhcp-relay
docker build -t labtainer-ubuntu-client:1.0 /home/student/labtainer/dockerfiles-common/labtainer-ubuntu-client
```

---

## 3. Cơ chế ánh xạ (Tag) vào bài lab theo quy ước Labtainers

Trong Labtainers, quy ước định danh image của 1 container trong lab là: `<tên-lab>.<tên-container>.student`.

Để một bài lab (ví dụ `dhcp-flooding` hoặc `dhcp-starvation`) sử dụng lại đúng bộ image chuẩn hóa mà **không cần build lại image**, chỉ cần chạy lệnh gán tag:
```bash
# Ánh xạ cho lab dhcp-flooding:
docker tag labtainer-dhcp-server:1.0 dhcp-flooding.dhcpserver.student
docker tag labtainer-dhcp-relay:1.0 dhcp-flooding.dhcprelay.student
docker tag labtainer-kali-attacker:1.0 dhcp-flooding.attacker.student
docker tag labtainer-ubuntu-client:1.0 dhcp-flooding.client.student
```

### Cách bài lab tiếp theo (ví dụ `dhcp-starvation`) tái sử dụng:
1. Tạo lab mới: `/home/student/labtainer/trunk/labs/dhcp-starvation/`
2. Ánh xạ tag:
   ```bash
   docker tag labtainer-dhcp-server:1.0 dhcp-starvation.dhcpserver.student
   docker tag labtainer-kali-attacker:1.0 dhcp-starvation.attacker.student
   docker tag labtainer-ubuntu-client:1.0 dhcp-starvation.client.student
   ```
3. Khởi động labtainer mà không phát sinh thêm dung lượng ổ đĩa hay build trùng lặp.

---

## 4. Tách biệt giữa Image dùng chung và Dữ liệu riêng của Lab
- **Trong Docker Image:** Chỉ chứa hệ điều hành, công cụ mạng, user `ubuntu` chuẩn và các daemon dịch vụ. **Hoàn toàn không gán cứng IP tĩnh, subnet hay file cấu hình của bài lab**.
- **Trong thư mục bài lab:** Chứa file cấu hình mạng riêng (`config/start.config`), file cấu hình dịch vụ riêng (`dhcpserver/_system/etc/dhcp/dhcpd.conf`), và script bổ trợ riêng (`bin/poststart`).
