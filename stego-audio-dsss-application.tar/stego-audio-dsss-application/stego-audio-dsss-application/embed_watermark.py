#!/usr/bin/env python3
# embed_watermark.py
# Embed copyright watermark into audio using DSSS.

import json
import numpy as np
from pathlib import Path

from common_dsss import (
    read_wav_mono,
    write_wav_mono,
    bytes_to_bits,
    int_to_32bits,
    generate_pn,
    spread_bits,
    compute_audio_metrics
)


INPUT_AUDIO = "original_audio.wav"
OWNER_INFO = "owner_info.txt"
OUTPUT_AUDIO = "watermarked_audio.wav"
KEY_FILE = "watermark_key.json"
REPORT_FILE = "embed_report.txt"

SECRET_SEED = 202607
CHIPS_PER_BIT = 512
EMBED_AMPLITUDE = 0.012


def main():
    sample_rate, original = read_wav_mono(INPUT_AUDIO)
    watermark_bytes = Path(OWNER_INFO).read_bytes()

    payload_bits = bytes_to_bits(watermark_bytes)
    length_bits = int_to_32bits(len(watermark_bytes))
    all_bits = np.concatenate([length_bits, payload_bits])

    n_bits = len(all_bits)
    n_chips = n_bits * CHIPS_PER_BIT

    if n_chips > len(original):
        raise ValueError("Audio is too short for this watermark.")

    pn = generate_pn(SECRET_SEED, n_chips)
    watermark_signal = spread_bits(all_bits, pn, CHIPS_PER_BIT)

    watermarked = original.copy()
    watermarked[:n_chips] = (
        watermarked[:n_chips] + EMBED_AMPLITUDE * watermark_signal
    )

    watermarked = np.clip(watermarked, -1.0, 1.0)

    write_wav_mono(OUTPUT_AUDIO, sample_rate, watermarked)

    key_data = {
        "algorithm": "DSSS audio watermark",
        "seed": SECRET_SEED,
        "chips_per_bit": CHIPS_PER_BIT,
        "n_bits": int(n_bits),
        "n_chips": int(n_chips),
        "watermark_length_bytes": len(watermark_bytes),
        "embed_amplitude": EMBED_AMPLITUDE,
        "sample_rate": sample_rate,
        "watermarked_file": OUTPUT_AUDIO
    }

    Path(KEY_FILE).write_text(
        json.dumps(key_data, indent=2),
        encoding="utf-8"
    )

    metrics = compute_audio_metrics(original, watermarked)

    report_lines = []
    report_lines.append("DSSS Audio Watermark Embedding Report")
    report_lines.append("=" * 50)
    report_lines.append(f"Input audio: {INPUT_AUDIO}")
    report_lines.append(f"Output audio: {OUTPUT_AUDIO}")
    report_lines.append(f"Watermark source: {OWNER_INFO}")
    report_lines.append(f"Watermark length: {len(watermark_bytes)} bytes")
    report_lines.append(f"Chips per bit: {CHIPS_PER_BIT}")
    report_lines.append(f"Embedding amplitude: {EMBED_AMPLITUDE}")
    report_lines.append("")
    report_lines.append("Audio quality metrics:")
    report_lines.append(f"MSE: {metrics['mse']}")
    report_lines.append(f"RMSE: {metrics['rmse']}")
    report_lines.append(f"SNR: {metrics['snr']} dB")
    report_lines.append(f"Mean absolute difference: {metrics['mean_abs_diff']}")
    report_lines.append(f"Max absolute difference: {metrics['max_abs_diff']}")
    report_lines.append("")
    report_lines.append("EMBED_RESULT: SUCCESS")

    report = "\n".join(report_lines)

    Path(REPORT_FILE).write_text(report, encoding="utf-8")

    print(report)
    print("[OK] Created", OUTPUT_AUDIO)
    print("[OK] Created", KEY_FILE)
    print("[OK] Created", REPORT_FILE)


if __name__ == "__main__":
    main()
