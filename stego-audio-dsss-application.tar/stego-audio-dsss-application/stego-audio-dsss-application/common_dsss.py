#!/usr/bin/env python3
# common_dsss.py
# Common DSSS and WAV helper functions.

import wave
import numpy as np


def read_wav_mono(path):
    with wave.open(path, "rb") as wf:
        channels = wf.getnchannels()
        sample_width = wf.getsampwidth()
        sample_rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sample_width != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0

    if channels > 1:
        audio = audio.reshape(-1, channels).mean(axis=1)

    return sample_rate, audio


def write_wav_mono(path, sample_rate, audio):
    samples = np.int16(np.clip(audio, -1.0, 1.0) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(samples.tobytes())


def bytes_to_bits(data):
    return np.unpackbits(np.frombuffer(data, dtype=np.uint8))


def bits_to_bytes(bits):
    bits = np.asarray(bits, dtype=np.uint8)
    n = (len(bits) // 8) * 8

    if n == 0:
        return b""

    return np.packbits(bits[:n]).tobytes()


def int_to_32bits(value):
    return np.array(
        [(value >> i) & 1 for i in range(31, -1, -1)],
        dtype=np.uint8
    )


def bits32_to_int(bits):
    value = 0

    for bit in bits[:32]:
        value = (value << 1) | int(bit)

    return value


def generate_pn(seed, n_chips):
    rng = np.random.default_rng(int(seed))

    return rng.choice(
        np.array([-1.0, 1.0], dtype=np.float32),
        size=int(n_chips)
    )


def spread_bits(bits, pn, chips_per_bit):
    symbols = np.where(bits == 1, 1.0, -1.0).astype(np.float32)
    expanded = np.repeat(symbols, chips_per_bit)

    return expanded * pn[:len(expanded)]


def despread_bits(received, pn, chips_per_bit, n_bits):
    received = received[:n_bits * chips_per_bit]
    pn = pn[:n_bits * chips_per_bit]

    recovered = []

    for i in range(n_bits):
        start = i * chips_per_bit
        end = start + chips_per_bit

        corr = float(np.dot(received[start:end], pn[start:end]))

        if corr >= 0:
            recovered.append(1)
        else:
            recovered.append(0)

    return np.array(recovered, dtype=np.uint8)


def compute_similarity(text_a, text_b):
    if len(text_a) == 0:
        return 0.0

    min_len = min(len(text_a), len(text_b))
    correct = 0

    for i in range(min_len):
        if text_a[i] == text_b[i]:
            correct += 1

    return correct / len(text_a)


def compute_audio_metrics(original, test):
    min_len = min(len(original), len(test))

    original = original[:min_len]
    test = test[:min_len]

    diff = test - original

    mse = float(np.mean(diff ** 2))
    rmse = float(np.sqrt(mse))
    mean_abs_diff = float(np.mean(np.abs(diff)))
    max_abs_diff = float(np.max(np.abs(diff)))

    signal_power = float(np.mean(original ** 2))
    noise_power = float(np.mean(diff ** 2))

    if noise_power == 0:
        snr = float("inf")
    else:
        snr = float(10 * np.log10(signal_power / noise_power))

    return {
        "mse": mse,
        "rmse": rmse,
        "mean_abs_diff": mean_abs_diff,
        "max_abs_diff": max_abs_diff,
        "snr": snr
    }
