#!/usr/bin/env python3
# generate_audio.py
# Create an original audio file for watermark application lab.

import wave
import numpy as np


SAMPLE_RATE = 44100
DURATION_SECONDS = 14
OUTPUT_FILE = "original_audio.wav"


def main():
    t = np.arange(int(SAMPLE_RATE * DURATION_SECONDS)) / SAMPLE_RATE

    signal = (
        0.18 * np.sin(2 * np.pi * 440 * t) +
        0.08 * np.sin(2 * np.pi * 660 * t) +
        0.05 * np.sin(2 * np.pi * 880 * t)
    )

    # Add very small natural-like background variation.
    rng = np.random.default_rng(2026)
    background = rng.normal(0, 0.003, size=len(signal))

    audio = signal + background
    samples = np.int16(np.clip(audio, -1.0, 1.0) * 32767)

    with wave.open(OUTPUT_FILE, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(samples.tobytes())

    print("[OK] Created", OUTPUT_FILE)
    print("[INFO] Sample rate:", SAMPLE_RATE)
    print("[INFO] Duration:", DURATION_SECONDS, "seconds")


if __name__ == "__main__":
    main()
