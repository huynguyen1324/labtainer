#!/usr/bin/env python3
# tamper_audio.py
# Simulate a modified copy of the watermarked audio.

import numpy as np

from common_dsss import read_wav_mono, write_wav_mono


INPUT_AUDIO = "watermarked_audio.wav"
OUTPUT_AUDIO = "tampered_audio.wav"


def main():
    sample_rate, audio = read_wav_mono(INPUT_AUDIO)

    # Simulate simple unauthorized editing:
    # 1. Reduce amplitude slightly.
    # 2. Add small Gaussian noise.
    # 3. Apply a simple smoothing filter.
    rng = np.random.default_rng(123)

    modified = audio * 0.92
    modified = modified + rng.normal(0, 0.01, size=len(modified)).astype(np.float32)

    kernel = np.ones(5, dtype=np.float32) / 5
    modified = np.convolve(modified, kernel, mode="same")

    modified = np.clip(modified, -1.0, 1.0)

    write_wav_mono(OUTPUT_AUDIO, sample_rate, modified)

    print("[OK] Created", OUTPUT_AUDIO)
    print("[INFO] This file simulates a modified copy of the watermarked audio.")


if __name__ == "__main__":
    main()
