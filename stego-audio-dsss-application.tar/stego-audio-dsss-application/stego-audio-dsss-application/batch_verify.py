#!/usr/bin/env python3
# batch_verify.py
# Verify watermark from multiple audio files.

from pathlib import Path

from verify_watermark import verify


AUDIO_FILES = [
    "original_audio.wav",
    "watermarked_audio.wav",
    "tampered_audio.wav"
]

OUTPUT_REPORT = "batch_verification_report.txt"


def main():
    lines = []
    lines.append("Batch DSSS Watermark Verification Report")
    lines.append("=" * 55)
    lines.append("")

    for audio_file in AUDIO_FILES:
        if not Path(audio_file).exists():
            lines.append(f"File: {audio_file}")
            lines.append("Status: MISSING")
            lines.append("")
            continue

        result = verify(audio_file)

        lines.append(f"File: {audio_file}")
        lines.append(f"Status: {result['status']}")
        lines.append(f"Reason: {result['reason']}")
        lines.append(f"Similarity: {result['similarity']}")
        lines.append("")

    report = "\n".join(lines)

    Path(OUTPUT_REPORT).write_text(report, encoding="utf-8")

    print(report)
    print("[OK] Report saved to", OUTPUT_REPORT)


if __name__ == "__main__":
    main()
