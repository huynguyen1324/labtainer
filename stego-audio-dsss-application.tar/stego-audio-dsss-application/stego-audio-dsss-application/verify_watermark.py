#!/usr/bin/env python3
# verify_watermark.py
# Verify copyright watermark from an audio file.

import sys
import json
from pathlib import Path

from common_dsss import (
    read_wav_mono,
    generate_pn,
    despread_bits,
    bits32_to_int,
    bits_to_bytes,
    compute_similarity
)


DEFAULT_AUDIO = "watermarked_audio.wav"
OWNER_INFO = "owner_info.txt"
KEY_FILE = "watermark_key.json"


def verify(input_audio):
    key_data = json.loads(Path(KEY_FILE).read_text(encoding="utf-8"))

    seed = int(key_data["seed"])
    chips_per_bit = int(key_data["chips_per_bit"])
    n_bits = int(key_data["n_bits"])
    n_chips = int(key_data["n_chips"])

    sample_rate, audio = read_wav_mono(input_audio)

    if len(audio) < n_chips:
        return {
            "input_audio": input_audio,
            "status": "FAILED",
            "reason": "Audio too short",
            "watermark_text": "",
            "similarity": 0.0
        }

    received = audio[:n_chips]
    pn = generate_pn(seed, n_chips)

    bits = despread_bits(received, pn, chips_per_bit, n_bits)

    watermark_length = bits32_to_int(bits[:32])
    max_possible_bytes = max(0, (n_bits - 32) // 8)

    if watermark_length <= 0 or watermark_length > max_possible_bytes:
        return {
            "input_audio": input_audio,
            "status": "FAILED",
            "reason": "Invalid watermark length",
            "watermark_text": "",
            "similarity": 0.0
        }

    watermark_bits = bits[32:32 + watermark_length * 8]
    watermark_bytes = bits_to_bytes(watermark_bits)

    try:
        watermark_text = watermark_bytes.decode("utf-8")
    except UnicodeDecodeError:
        watermark_text = ""

    expected_text = Path(OWNER_INFO).read_text(encoding="utf-8")
    similarity = compute_similarity(expected_text, watermark_text)

    if watermark_text == expected_text:
        status = "VERIFIED"
        reason = "Exact watermark matched"
    elif similarity >= 0.80:
        status = "PARTIAL_MATCH"
        reason = "Watermark partially recovered"
    else:
        status = "FAILED"
        reason = "Watermark not matched"

    return {
        "input_audio": input_audio,
        "status": status,
        "reason": reason,
        "watermark_text": watermark_text,
        "similarity": similarity
    }


def main():
    input_audio = DEFAULT_AUDIO

    if len(sys.argv) >= 2:
        input_audio = sys.argv[1]

    result = verify(input_audio)

    report_file = Path(input_audio).stem + "_verification_report.txt"

    report_lines = []
    report_lines.append("DSSS Audio Watermark Verification Report")
    report_lines.append("=" * 55)
    report_lines.append(f"Input audio: {result['input_audio']}")
    report_lines.append(f"Verification status: {result['status']}")
    report_lines.append(f"Reason: {result['reason']}")
    report_lines.append(f"Similarity: {result['similarity']}")
    report_lines.append("")
    report_lines.append("Recovered watermark:")
    report_lines.append(result["watermark_text"])

    report = "\n".join(report_lines)

    Path(report_file).write_text(report, encoding="utf-8")

    print(report)
    print("[OK] Report saved to", report_file)


if __name__ == "__main__":
    main()
