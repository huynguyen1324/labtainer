# Bài lab: DHCP Starvation qua DHCP Relay

## 1. Mục tiêu và phạm vi

Trong topology Labtainers cô lập, quan sát cách một DHCP server cấp phát địa
chỉ qua relay và cách pool hết địa chỉ khiến client không nhận được lease.
Attacker và các gói DHCP của bài tập chỉ được chạy trên `eth0` của container
`attacker`, nối với mạng riêng `EXTERNAL_NET` của lab. Không chạy công cụ này
trên mạng thật, mạng trường học, mạng công cộng hoặc bất kỳ mạng nào khác.

## 2. Topology

| Container | Mạng | Địa chỉ cấu hình | Vai trò |
| --- | --- | --- | --- |
| `dhcpserver` | `INTERNAL_NET` | `192.168.0.100` | DHCP server; cấp pool External `10.10.0.100–10.10.0.130` |
| `dhcprelay` | Cả hai mạng | `192.168.0.1`, `10.10.0.1` | Chuyển tiếp DHCP giữa hai subnet |
| `attacker` | `EXTERNAL_NET` | `10.10.0.20` lúc khởi tạo | Máy thực hiện bài tập DHCP starvation |
| `client` | `EXTERNAL_NET` | `10.10.0.50` lúc khởi tạo | Client kiểm tra việc xin lease |

Image attacker và client xóa địa chỉ IPv4 khởi tạo khi container boot. Attacker
sẽ xin lease trước; client chưa xin IP cho đến sau khi pool cạn. Pool DHCP có
31 địa chỉ từ `10.10.0.100` đến `10.10.0.130`.

## 3. Giai đoạn 1: Kiểm tra dịch vụ và cấp lease ban đầu

### DHCP server

Trong terminal `dhcpserver`, kiểm tra dịch vụ được image khởi chạy:

```bash
systemctl status dhcp-server-init.service --no-pager
pgrep -a dhcpd
ip route show
```

### DHCP relay

Trong terminal `dhcprelay`, xác nhận forwarding và relay:

```bash
systemctl status dhcp-relay-init.service --no-pager
sysctl net.ipv4.ip_forward
pgrep -a dhcrelay
```

Mở một terminal `dhcprelay` để quan sát DHCP:

```bash
sudo tcpdump -i any -n 'port 67 or port 68'
```

### Chỉ attacker xin lease ban đầu

Không chạy `dhclient` trên client ở giai đoạn này. Trong terminal `attacker`:

```bash
sudo dhclient -v eth0
ip -4 addr show eth0
```

Xác nhận attacker nhận được địa chỉ trong dải `10.10.0.100–10.10.0.130`.
Trên `dhcpserver`, kiểm tra lease để thấy lease ban đầu thuộc attacker:

```bash
sudo grep -E 'lease 10\.10\.0\.|binding state' /var/lib/dhcp/dhcpd.leases
```

Nếu attacker chưa có lease, xử lý kết nối/dịch vụ trước khi tiếp tục. Client
vẫn chưa có IPv4 động; đây là trạng thái mong muốn trước khi starvation.

## 4. Giai đoạn 2: Thực hiện bài tập starvation trong lab

Chỉ trong terminal container `attacker`, chạy công cụ trên interface của
`EXTERNAL_NET`:

```bash
sudo dhcpstarv -i eth0
```

Trong bài tập này, các yêu cầu DHCP được xử lý qua relay; các lease mới tiêu
thụ dần địa chỉ có sẵn trong pool của server. Để theo dõi tiến độ, mở terminal
`dhcpserver` và chạy lệnh:

```bash
sudo grep -c 'binding state active;' /var/lib/dhcp/dhcpd.leases
```

Pool có 31 địa chỉ từ `10.10.0.100` đến `10.10.0.130`. Lệnh sẽ in số lease
active; khi kết quả là `31`, pool đã hết địa chỉ. Lặp lại lệnh nếu kết quả
thấp hơn. Chỉ chạy `dhcpstarv` sẽ làm `starvation_started` đạt `Y`.
`pool_exhausted` được chấm trực tiếp từ lease database, bằng cách đếm các dòng
`binding state active;` giống lệnh `grep -c`. Khi số đếm lớn hơn 30, mục tiêu
đạt `Y`.

## 5. Giai đoạn 3: Kiểm tra client khi pool đã cạn

Giữ `dhcpstarv` đang chạy. Chỉ sau khi server đã ghi nhận pool cạn, chuyển
sang terminal `client`. Client chưa từng xin lease nên **không** cần chạy
`dhclient -r`. Chạy lệnh sau để xin IP và lưu phản hồi cho `checkwork`:

```bash
sudo dhclient -1 -v eth0 2>&1 | tee /var/log/dhcp-starvation-client.log
```

Chờ lệnh tự kết thúc; không dùng `timeout` hoặc nhấn **Ctrl+C** trong lúc
`dhclient` đang thử. Khi pool cạn, client sẽ gửi `DHCPDISCOVER` nhưng không
nhận `DHCPOFFER`. Nếu client vẫn nhận được lease, pool chưa cạn tại thời điểm
yêu cầu hoặc starvation đã dừng quá sớm. Hãy kiểm tra lại số lease active.

Sau khi ghi nhận kết quả client, quay lại terminal attacker và nhấn **Ctrl+C**
để dừng `dhcpstarv`. Không để tiến trình chạy sau khi hoàn thành bài lab.

## 6. Đánh giá và kết thúc

Trên host Labtainer, dừng lab để thu thập kết quả rồi chấm bài:

```bash
stoplab dhcp-starvation
checkwork dhcp-starvation
```

Các mục tiêu:

| Mục tiêu | Bằng chứng |
| --- | --- |
| `attacker_has_ip` | Lease database của attacker ghi nhận địa chỉ được cấp từ pool External trước khi starvation bắt đầu. |
| `starvation_started` | Lịch sử lệnh của attacker ghi nhận đã chạy `sudo dhcpstarv -i eth0`. |
| `pool_exhausted` | Lease database có hơn 30 dòng `binding state active;`, tương ứng với kết quả `grep -c` bằng 31. |
| `client_unable_to_obtain_ip` | Log của client có yêu cầu `DHCPDISCOVER` nhưng không có phản hồi `DHCPOFFER`. |

Nếu muốn chạy lại từ đầu, khởi động lại lab với tùy chọn reset để xóa lease và
log cũ:

```bash
labtainer -r dhcp-starvation
```
