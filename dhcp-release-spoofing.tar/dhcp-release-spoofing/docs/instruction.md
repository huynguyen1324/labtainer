# HƯỚNG DẪN THỰC HÀNH BÀI LAB: DHCP RELEASE SPOOFING & IP HIJACKING

---

## 1. Sơ đồ mạng và phân bổ IP (Topology)

| Máy (Container) | Mạng kết nối | Địa chỉ IP ban đầu | IP sau khi bị cướp | Vai trò |
| :--- | :--- | :--- | :--- | :--- |
| **`dhcpserver`** | `INTERNAL_NET` (192.168.0.0/24) | `192.168.0.100` | `192.168.0.100` | DHCP Server quản lý cấp IP động (Pool: `10.10.0.100 - 10.10.0.130`) |
| **`dhcprelay`** | Nối cả 2 mạng | eth0: `192.168.0.1`<br>eth1: `10.10.0.1` | Không đổi | Chuyển tiếp DHCP giữa External $\leftrightarrow$ Internal |
| **`client`** | `EXTERNAL_NET` (10.10.0.0/24) | IP động đầu tiên | **IP động mới khác** (Bị mất IP cũ) | Máy nạn nhân bị tước đoạt IP |
| **`attacker`** | `EXTERNAL_NET` (10.10.0.0/24) | IP động tiếp theo | **Cướp IP cũ của Client** | Kẻ tấn công giả mạo Release và cướp IP |

---

## 2. GIAI ĐOẠN 1: Khởi động dịch vụ và cấp phát IP ban đầu

### Bước 1: Cấu hình và khởi động DHCP Server
Trên cửa sổ terminal **`dhcpserver`**:
```bash
# 1. Định tuyến quay về mạng External qua Relay
ip route add 10.10.0.0/24 via 192.168.0.1 dev eth0

# 2. Khởi động dịch vụ ISC DHCP Server
touch /var/lib/dhcp/dhcpd.leases
dhcpd -4 -cf /etc/dhcp/dhcpd.conf eth0

# 3. Kiểm tra tiến trình
pgrep -a dhcpd
```

---

### Bước 2: Cấu hình và khởi động DHCP Relay
Trên cửa sổ terminal **`dhcprelay`**:
```bash
# 1. Bật chuyển tiếp gói tin (IP Forwarding)
sysctl -w net.ipv4.ip_forward=1

# 2. Bật DHCP Relay chuyển tiếp về Server 192.168.0.100
dhcrelay -4 -i eth0 -i eth1 192.168.0.100

# 3. Bắt gói tin giám sát các gói DHCP bắt tay
tcpdump -i any -n port 67 or port 68
```

---

### Bước 3: Client xin cấp phát IP ban đầu (Checkwork 1)
Trên cửa sổ terminal **`client`**:
```bash
# Xin cấp IP động qua DHCP
dhclient -v eth0

# Kiểm tra IP nhận được
ip addr show eth0
```
> [!TIP]
> Máy `client` nhận được địa chỉ IP động từ DHCP Server.
> Thao tác này hoàn thành **Checkwork 1: `client_has_ip`**.

---

### Bước 4: Attacker xin cấp phát IP ban đầu (Checkwork 2)
Trên cửa sổ terminal **`attacker`**:
```bash
# Xin cấp IP động qua DHCP
dhclient -v eth0

# Kiểm tra IP nhận được
ip addr show eth0
```
> [!TIP]
> Máy `attacker` nhận được IP động từ DHCP Server.
> Thao tác này hoàn thành **Checkwork 2: `attacker_has_ip`**.

---

## 3. GIAI ĐOẠN 2: Tấn công DHCP Release Spoofing & Cướp IP (Checkwork 3)

### Bước 5: Quét ARP để thu thập IP và MAC của các máy trong mạng
Tại cửa sổ terminal **`attacker`**, sử dụng công cụ `arp-scan` để quét toàn bộ mạng cục bộ `eth0`:
```bash
sudo arp-scan --interface=eth0 --localnet
```

**Mục đích:**
- Xác định địa chỉ IP và địa chỉ MAC thật của máy nạn nhân (`client`) đang hoạt động trên mạng `10.10.0.0/24` (ví dụ: `10.10.0.100` với MAC `02:42:0a:0a:00:32`).
- Thu thập chính xác địa chỉ MAC để đưa vào công cụ giả mạo gói tin ở bước sau.

---

### Bước 6: Chạy công cụ Scapy trên Attacker (Checkwork 3)
Tại cửa sổ terminal **`attacker`**, chạy công cụ tấn công Python Scapy:
```bash
python3 /usr/local/bin/dhcp-release-spoofing.py
```

**Nhập các thông số thực tế thu được từ `arp-scan`:**
*(Lưu ý: Các giá trị hiển thị trong dấu ngoặc đơn chỉ là ví dụ gợi ý cú pháp, hãy gõ đúng giá trị tương ứng)*
1. `Enter network interface (e.g., eth0):` gõ `eth0`
2. `Enter DHCP Server IP address (e.g., 192.168.0.100):` gõ `192.168.0.100`
3. `Enter Victim Client IP address (e.g., 10.10.0.100):` gõ IP của Client thu được từ bước quét ARP (ví dụ: `10.10.0.100`)
4. `Enter Victim Client MAC address (e.g., 02:42:0a:0a:00:32):` gõ MAC của Client thu được từ bước quét ARP (ví dụ: `02:42:0a:0a:00:32`)

**Hiện tượng diễn ra tự động:**
- Script tự động giải phóng IP động cũ của Attacker.
- Gửi gói tin `DHCPRELEASE` giả mạo MAC và IP của Client lên DHCP Server để hủy lease của nạn nhân.
- Cướp lấy IP của Client, gán trực tiếp vào card `eth0` của Attacker và phát gói Gratuitous ARP để toàn mạng nhận Attacker là chủ sở hữu mới.
- Hiển thị thông báo cướp IP thành công và kết thúc script:
  ```text
  [+] SUCCESS: Successfully hijacked Client IP 10.10.0.100!
  [+] IP 10.10.0.100 is now active on Attacker interface (eth0).
  [+] Attack script completed. Exiting.
  ```
> [!TIP]
> Thao tác này hoàn thành **Checkwork 3: `attack_success`**.

---

## 4. GIAI ĐOẠN 3: Client xin cấp lại IP và nhận IP khác (Checkwork 4)

### Bước 7: Client giải phóng và xin cấp lại IP
Chuyển sang cửa sổ terminal **`client`**:
```bash
# 1. Giải phóng IP hiện tại
dhclient -r eth0

# 2. Xin cấp phát lại IP
dhclient -v eth0

# 3. Kiểm tra IP mới nhận được
ip addr show eth0
```

**Hiện tượng quan sát:**
- Do IP ban đầu của Client đã bị Attacker chiếm giữ và phát Gratuitous ARP, DHCP Server nhận diện IP đó đang bận nên cấp cho Client một IP động khác trong dải.
- Client chính thức bị tước đoạt IP cũ.
> [!TIP]
> Thao tác này hoàn thành **Checkwork 4: `client_got_different_ip`**.

---

## 5. GIAI ĐOẠN 4: Giám sát mạng và thu thập gói tin từ Server (Checkwork 5)

### Bước 8: Mở công cụ giám sát mạng trên Attacker
Tại cửa sổ terminal **`attacker`**, sử dụng công cụ `tcpdump` để theo dõi lưu lượng mạng:
```bash
sudo tcpdump -i eth0 -n icmp
```
> [!NOTE]
> Giữ cửa sổ terminal này để quan sát các gói tin được gửi tới IP mà Attacker vừa cướp được.

---

### Bước 9: Server gửi gói tin kiểm tra tới IP Client
Trên cửa sổ terminal **`dhcpserver`**:
Người quản trị Server gửi gói tin kiểm tra kết nối (Ping) tới địa chỉ IP ban đầu của Client (ví dụ `10.10.0.100`):
```bash
ping -c 3 10.10.0.100
```

**Hiện tượng quan sát:**
- Tại terminal **`dhcpserver`**: Lệnh ping phản hồi thành công 100% (Server tưởng rằng Client đang trả lời).
- Tại terminal **`attacker`**: Công cụ `tcpdump` bắt được trực tiếp các gói tin ICMP Request/Reply:
  ```text
  IP 192.168.0.100 > 10.10.0.100: ICMP echo request, id 1, seq 1, length 64
  IP 10.10.0.100 > 192.168.0.100: ICMP echo reply, id 1, seq 1, length 64
  ```
- Minh chứng Attacker đã đánh cắp thành công danh tính mạng của Client và thu trọn luồng dữ liệu từ Server gửi tới!
> [!TIP]
> Thao tác này hoàn thành **Checkwork 5: `traffic_intercepted`**.

---

## 6. ĐÁNH GIÁ VÀ NỘP BÀI (CHECKWORK)

Tại terminal máy host (`student@LabtainerVMware`), gõ:
```bash
checkwork dhcp-release-spoofing
```
Bảng đánh giá hiển thị chuẩn 5 tiêu chí:

| Mục tiêu chấm điểm | Trạng thái mong muốn | Mô tả chi tiết |
| :--- | :---: | :--- |
| **`client_has_ip`** | **Y** | Client successfully obtained dynamic IP from DHCP Server |
| **`attacker_has_ip`** | **Y** | Attacker successfully obtained dynamic IP from DHCP Server |
| **`attack_success`** | **Y** | Attacker executed Scapy release spoofing and hijacked victim IP |
| **`client_got_different_ip`** | **Y** | Client re-requested dynamic IP and received a different IP address |
| **`traffic_intercepted`** | **Y** | DHCP Server communicated with victim IP and Attacker captured the traffic |
