# HƯỚNG DẪN THỰC HÀNH BÀI LAB: DHCP RELEASE SPOOFING & IP HIJACKING

---

## 1. Sơ đồ mạng và phân bổ IP (Topology)

| Máy (Container) | Mạng kết nối | Địa chỉ IP ban đầu | IP sau khi bị cướp | Vai trò |
| :--- | :--- | :--- | :--- | :--- |
| **`dhcpserver`** | `INTERNAL_NET` (192.168.0.0/24) | `192.168.0.100` | `192.168.0.100` | DHCP Server quản lý cấp IP động (Pool: `10.10.0.100 - 10.10.0.130`) |
| **`dhcprelay`** | Nối cả 2 mạng | eth0: `192.168.0.1`<br>eth1: `10.10.0.1` | Không đổi | Chuyển tiếp DHCP giữa External $\leftrightarrow$ Internal |
| **`client`** | `EXTERNAL_NET` (10.10.0.0/24) | IP động đầu tiên | **IP động mới khác** (Bị mất IP cũ) | Máy nạn nhân bị tước đoạt IP |
| **`attacker`** | `EXTERNAL_NET` (10.10.0.0/24) | IP động tiếp theo | **Cướp IP cũ của Client** | Kẻ tấn công giả mạo Release và cướp IP |

---

## 2. GIAI ĐOẠN 1: Kiểm tra dịch vụ và cấp phát IP ban đầu

### Bước 1: Kiểm tra DHCP Server
Trên cửa sổ terminal **`dhcpserver`**:
```bash
# Image cấu hình route và khởi động DHCP Server khi container boot.
systemctl status dhcp-server-init.service --no-pager
pgrep -a dhcpd
ip route show
```

> **Điều kiện đạt checkwork:** Không có (Bước chuẩn bị hạ tầng mạng và khởi động dịch vụ máy chủ).

---

### Bước 2: Kiểm tra DHCP Relay
Trên cửa sổ terminal **`dhcprelay`**:
```bash
# Image bật forwarding và khởi động relay khi container boot.
systemctl status dhcp-relay-init.service --no-pager
sysctl net.ipv4.ip_forward
pgrep -a dhcrelay

# Bắt gói tin giám sát DHCP
tcpdump -i any -n port 67 or port 68
```

> **Điều kiện đạt checkwork:** Không có (Bước chuẩn bị chuyển tiếp DHCP và kích hoạt giám sát lưu lượng).

---

### Bước 3: Client xin cấp phát IP ban đầu (Checkwork 1)
Trên cửa sổ terminal **`client`**:
```bash
# Xin cấp IP động qua DHCP
dhclient -v eth0

# Kiểm tra IP nhận được
ip addr show eth0
```
> [!TIP]
> Máy `client` nhận được địa chỉ IP động từ DHCP Server (ví dụ: `10.10.0.100`).

> **Điều kiện đạt checkwork:** Mục tiêu **`client_has_ip`** chuyển sang **Y** khi file `/var/lib/dhcp/dhclient.leases` trên máy `client` ghi nhận địa chỉ IP động được cấp phát từ DHCP Server trong dải `10.10.0.0/24`.

---

### Bước 4: Attacker xin cấp phát IP ban đầu (Checkwork 2)
Trên cửa sổ terminal **`attacker`**:
```bash
# Xin cấp IP động qua DHCP
dhclient -v eth0

# Kiểm tra IP nhận được
ip addr show eth0
```
> [!TIP]
> Máy `attacker` nhận được IP động từ DHCP Server (ví dụ: `10.10.0.101`).

> **Điều kiện đạt checkwork:** Mục tiêu **`attacker_has_ip`** chuyển sang **Y** khi file `/var/lib/dhcp/dhclient.leases` trên máy `attacker` ghi nhận địa chỉ IP động được cấp phát từ DHCP Server trong dải `10.10.0.0/24`.

---

## 3. GIAI ĐOẠN 2: Tấn công DHCP Release Spoofing & Cướp IP (Checkwork 3)

### Bước 5: Quét ARP để thu thập IP và MAC của các máy trong mạng
Tại cửa sổ terminal **`attacker`**, sử dụng công cụ `arp-scan` để quét toàn bộ mạng cục bộ `eth0`:
```bash
sudo arp-scan --interface=eth0 --localnet
```

**Mục đích:**
- Xác định địa chỉ IP và địa chỉ MAC thật của máy nạn nhân (`client`) đang hoạt động trên mạng `10.10.0.0/24` (ví dụ: `10.10.0.100` với MAC `02:42:0a:0a:00:32`).
- Thu thập chính xác địa chỉ MAC để đưa vào công cụ giả mạo gói tin ở bước sau.

> **Điều kiện đạt checkwork:** Không có (Bước trinh sát thu thập thông tin IP và MAC mục tiêu của nạn nhân).

---

### Bước 6: Chạy công cụ Scapy trên Attacker (Checkwork 3)
Tại cửa sổ terminal **`attacker`**, chạy công cụ tấn công Python Scapy:
```bash
python3 /usr/local/bin/dhcp-release-spoofing.py
```

**Nhập các thông số thực tế thu được từ `arp-scan`:**
*(Lưu ý: Các giá trị hiển thị trong dấu ngoặc đơn chỉ là ví dụ gợi ý cú pháp, hãy gõ đúng giá trị tương ứng)*
1. `Enter network interface (e.g., eth0):` gõ `eth0`
2. `Enter DHCP Server IP address (e.g., 192.168.0.100):` gõ `192.168.0.100`
3. `Enter Victim Client IP address (e.g., 10.10.0.100):` gõ IP của Client thu được từ bước quét ARP (ví dụ: `10.10.0.100`)
4. `Enter Victim Client MAC address (e.g., 02:42:0a:0a:00:32):` gõ MAC của Client thu được từ bước quét ARP (ví dụ: `02:42:0a:0a:00:32`)

**Hiện tượng diễn ra tự động:**
- Script tự động giải phóng IP động cũ của Attacker.
- Gửi gói tin `DHCPRELEASE` giả mạo MAC và IP của Client lên DHCP Server để hủy lease của nạn nhân.
- Thử gán IP của Client lên card `eth0` của Attacker và phát gói Gratuitous ARP. Đây chỉ là thao tác phía Attacker; nó không chứng minh DHCP Server đã chuyển lease hoặc Client đã mất IP.
- Script ghi nhận lần thử và yêu cầu kiểm tra kết quả thực tế:
  ```text
  [*] Attempt completed; the client's lease and connectivity were not verified.
  [*] Check the client lease and network observations to assess the outcome.
  ```

> **Điều kiện đạt checkwork:** Mục tiêu **`attack_attempted`** xác nhận script đã chạy và ghi nhận lần thử. Mục tiêu này không khẳng định hijack thành công; **`client_got_different_ip`** mới xác nhận Client đã nhận lease khác.

---

## 4. GIAI ĐOẠN 3: Client xin cấp lại IP và nhận IP khác (Checkwork 4)

### Bước 7: Client giải phóng và xin cấp lại IP
Chuyển sang cửa sổ terminal **`client`**:
```bash
# 1. Giải phóng IP hiện tại
dhclient -r eth0

# 2. Xin cấp phát lại IP
dhclient -v eth0

# 3. Kiểm tra IP mới nhận được
ip addr show eth0
```

**Hiện tượng quan sát:**
- Do IP ban đầu của Client đã bị Attacker chiếm giữ và phát Gratuitous ARP, DHCP Server nhận diện IP đó đang bận nên cấp cho Client một IP động khác trong dải.
- Client chính thức bị tước đoạt IP cũ.

> **Điều kiện đạt checkwork:** Mục tiêu **`client_got_different_ip`** chuyển sang **Y** khi file `/var/lib/dhcp/dhclient.leases` trên máy `client` ghi nhận địa chỉ IP động mới được cấp phát khác với IP cũ (nhận một IP từ `10.10.0.101` đến `10.10.0.130`).

---

## 5. GIAI ĐOẠN 4: Giám sát mạng và thu thập gói tin từ Server (Checkwork 5)

### Bước 8: Mở công cụ giám sát mạng trên Attacker
Tại cửa sổ terminal **`attacker`**, sử dụng công cụ `tcpdump` để theo dõi lưu lượng mạng:
```bash
sudo tcpdump -i eth0 -n icmp
```
> [!NOTE]
> Giữ cửa sổ terminal này để quan sát các gói tin được gửi tới IP mà Attacker vừa cướp được.

> **Điều kiện đạt checkwork:** Không có (Bước khởi chạy công cụ lắng nghe lưu lượng mạng ICMP).

---

### Bước 9: Server gửi gói tin kiểm tra tới IP Client
Trên cửa sổ terminal **`dhcpserver`**:
Người quản trị Server gửi gói tin kiểm tra kết nối (Ping) tới địa chỉ IP ban đầu của Client (ví dụ `10.10.0.100`):
```bash
ping -c 3 10.10.0.100
```

**Hiện tượng quan sát:**
- Tại terminal **`dhcpserver`**: Lệnh ping phản hồi thành công 100% (Server tưởng rằng Client đang trả lời).
- Tại terminal **`attacker`**: Công cụ `tcpdump` bắt được trực tiếp các gói tin ICMP Request/Reply:
  ```text
  IP 192.168.0.100 > 10.10.0.100: ICMP echo request, id 1, seq 1, length 64
  IP 10.10.0.100 > 192.168.0.100: ICMP echo reply, id 1, seq 1, length 64
  ```
- Minh chứng Attacker đã đánh cắp thành công danh tính mạng của Client và thu trọn luồng dữ liệu từ Server gửi tới!

> **Điều kiện đạt checkwork:** Mục tiêu **`traffic_intercepted`** chuyển sang **Y** khi `/var/log/traffic.log` ghi nhận `ICMP echo request` từ DHCP Server tới IP mục tiêu. Các gói DHCP khác không làm mục tiêu này đạt.

---

## 6. ĐÁNH GIÁ VÀ NỘP BÀI (CHECKWORK)

Tại terminal máy host (`student@LabtainerVMware`), gõ:
```bash
checkwork dhcp-release-spoofing
```
Bảng đánh giá hiển thị chuẩn 5 tiêu chí:

| Mục tiêu chấm điểm | Trạng thái mong muốn | Mô tả chi tiết |
| :--- | :---: | :--- |
| **`client_has_ip`** | **Y** | Client successfully obtained dynamic IP from DHCP Server |
| **`attacker_has_ip`** | **Y** | Attacker successfully obtained dynamic IP from DHCP Server |
| **`attack_attempted`** | **Y** | Attacker ran the release-spoofing exercise; this does not prove the client lost its lease |
| **`client_got_different_ip`** | **Y** | Client re-requested dynamic IP and received a different IP address |
| **`traffic_intercepted`** | **Y** | DHCP Server communicated with victim IP and Attacker captured the traffic |
